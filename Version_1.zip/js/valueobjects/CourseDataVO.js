var CourseDataVO = function(){
	this.projectTitle = "";
	this.title = "";
	this.baseURL = "";
	this.contentURL = "";
	this.isCourseEnable = "";
	this.instructionData = "";
	this.duration = "";
	this.resources = "";
	this.handouts = "";
	this.desktopHelp = "";
}