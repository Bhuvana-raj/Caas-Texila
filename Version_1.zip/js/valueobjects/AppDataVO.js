var AppDataVO = function(props){
	this.serverURL = props.serverURL;
	this.isEncrypted = props.isEncrypted;
	this.courseName = props.courseName;
	this.dataType = props.dataType;
	this.scorm = props.scorm;
	this.language = props.language;
	this.desktopPaginationCount = props.desktopPaginationCount;
	this.mobilePaginationCount = props.mobilePaginationCount;
	this.linear = props.linear;
	this.templateLocation = props.templateLocation;
}