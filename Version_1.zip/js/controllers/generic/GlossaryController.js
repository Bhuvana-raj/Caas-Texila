/**
 * Created by Venkatesh on 8/16/2016.
 */

var GlossaryController = function(){

	var _this = this;	
	var glossaryData, innerCount, hasGlossary, className, tempSrc, glossaryMenuLoop;

    this.init = function(data){
        trace(":: Glossary Controller Invoked ::");
		_this.glossaryData = data.glossary;
        _this.paintUI();
    }

    this.paintUI = function(){
        trace(":: Create Glossary UI ::");

		$("#alphabetContainer, #glossaryMenu, #glossaryDescription").html('');
		tempSrc = "";
		for(var i = 0; i < _this.glossaryData.length; i++){
			hasGlossary = _this.glossaryData[i].alphabetContent.length;
			if(hasGlossary)
				className = '';
			else
				className = 'class="noGlossary"';
			tempSrc += "<button data-innerid='" + i + "' "+ className+">"+ _this.glossaryData[i].alphabet.toUpperCase() +"</button>";
		}	
		
		$("#alphabetContainer").html(tempSrc);
		$("#alphabetContainer button").unbind("click").bind("click", _this.alphabetMenuList);
		
		$("#alphabetContainer button:eq(0)").trigger('click'); // For displaying active to first
	}
	
	this.alphabetMenuList = function(event){
		$("#alphabetContainer button").removeClass("active");
		$("#glossaryDescription, #glossaryMenu button").empty();
		innerCount = (_this.glossaryData[event.currentTarget.dataset.innerid].alphabetContent).length;
		glossaryMenuLoop = "";
		for(var j = 0; j < innerCount; j++){
			glossaryMenuLoop += "<button data-innerid='" + event.currentTarget.dataset.innerid + "' data-outerid='" + j + "'>"+ _this.glossaryData[event.currentTarget.dataset.innerid].alphabetContent[j].menu +"</button>";
		} 
		$("#glossaryMenu").html('').html(glossaryMenuLoop);
		$("#glossaryMenu button").unbind("click").bind("click", _this.alphabetDescriptionList);	
		
		$("#glossaryMenu button:eq(0)").trigger('click');	// For displaying active to first
		
		$("#alphabetContainer button:eq("+event.currentTarget.dataset.innerid+")").addClass("active");
	}
	
	this.alphabetDescriptionList = function(event){
		$("#glossaryDescription").empty();
		$("#glossaryMenu button").removeClass("active");
		$("#glossaryMenu button:eq("+event.currentTarget.dataset.outerid+")").addClass("active");
		$("#glossaryDescription").html('').html("<p>"+ _this.glossaryData[event.currentTarget.dataset.innerid].alphabetContent[event.currentTarget.dataset.outerid].content +"</p>");
	}
	
}