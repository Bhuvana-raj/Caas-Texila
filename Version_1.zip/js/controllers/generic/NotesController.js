/**
 * Created by Venkatesh on 5/12/2017.
 */

var NotesController = function(){

	var $this = this;
	var notes, allNotes, notesContent, printContents, buttons;
	this.appReference;

    this.init = function(curpage){
        trace(":: Notes Controller Invoked ::");
		
		$this.appReference = curpage;
						 
        $this.paintUI();
    }

    this.paintUI = function(){
        trace(":: Create Notes UI ::");
		
		$("#notesText").off("input").on("input", $this.notesSaveHandler);	
		$("#allNotes").off("click").on("click", $this.allNotesHandler);
        $("#notesClose").off("click").on("click", $this.notesCloseBtnHandler);  
        $("#printNotes").off("click").on("click", $this.notesPrintBtnHandler);  
	}
	
	this.notesSaveHandler = function(){ 
	
		$this.appReference.notesArray[$this.appReference.currentIndex].noteData = "";
		$this.appReference.notesArray[$this.appReference.currentIndex].noteData = $("#notesText").val();
		
		if(localStorage.getItem('notes_data') != null){
			localStorage.setItem("notes_data",JSON.stringify($this.appReference.notesArray) );
		}
		
		$("#allNotes").removeClass("disabled").prop('disabled', false);
	}
	
	this.notesCloseBtnHandler = function(){
		$(".glossaryBtn").attr('tabindex','0').focus();
		$("#notes").hide();
		$(".notesBtn > a > img").attr("src","assets/images/notes_icon.png");
	}
	
	
	/* $("#displayAllNotes").on("focus", function(){
		$(this).css("outline: 5px solid red");
	}); */
	
	this.allNotesHandler = function(){
		
		$('#notes').hide();
		
		$("#myModal1").attr('aria-live','assertive');
		$("#myModal1").attr('tabindex','0').focus();
		
		$('#myModal1').modal('show');
		
		allNotes = JSON.parse(localStorage.getItem("notes_data"));
				
		notesContent = printContents = "";
		
		buttons = '<button type="button"  id="eachNotes">View Each</button>';
		
		for(var i = 0; i < allNotes.length; i++){
			if((allNotes[i].noteData != undefined) && (allNotes[i].noteData != "")){
				notesContent += '<h2>Slide - '+( i+ parseInt(1))+buttons+'</h2><p>'+allNotes[i].noteData+'</p>';
				printContents += '<h2>Slide - '+( i+ parseInt(1))+'</h2><p>'+allNotes[i].noteData+'</p>';
				buttons = '';
			}
		}
		
		$("#displayAllNotes").html("").html(notesContent);
		
		$("#eachNotes").off("click").on("click", $this.eachNotesHandler);
		$("#myModal1").on("hidden.bs.modal", $this.eachNotesHandler);
		
	}
	
	this.eachNotesHandler = function(){
		
		$("#notes").attr('tabindex','0').focus();
		$('#myModal1').modal('hide');
		$('#notes').show();
	}
	
	this.notesPrintBtnHandler = function(){
		
		var printWindow = window.open('', '', 'height=400,width=800');
		printWindow.document.write('<html><head><title>Pearson AOP Notes</title></head><body >');
		printWindow.document.write(printContents);
		printWindow.document.write('</body></html>');
		printWindow.document.close();
		printWindow.print();
	}
		
}