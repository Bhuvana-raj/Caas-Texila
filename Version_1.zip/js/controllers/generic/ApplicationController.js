/**
 * Created by Ravi Sharma on 6/20/2016.
 */

var ApplicationController = function () {

    var currentRef = this; //hack to get the reference of the current class
    var menu_tick, active_state;
	var currentTemplate;
    var currentTemplateObj;
    this._model = DataManager.getInstance();
    this.currentIndex = 0;
    this.audioManager;
    this.currentPageTranscript = "";
    this.currentPageJSONData;
    this.currentPageToLoadObj;

    this.audioMuteFlag = true;
    this.playPauseFlag = true;
	this.VideoplaypauseFlag;
	
	this.courseTrackObj = new Object();
	this.courseTrackObj.currentIndex = 0;
	this.courseTrackObj.curChapterIndex = 0;
	this.courseTrackObj.curPageIndex = 0;
	
    this.menuStatusArr = new Array();

	this.curChapterIndex = 0;
	this.curPageIndex = 0;
	
	this.popupAudioplayPauseFlag = false;
	this.popupAudioMuteFlag = false;
	
	this.isMainAudioPlaying = false;
	this.isPopupAudioPlaying = false;
	this.isCCTextPlaying = false;
	
	this.createJSRef = '';
	this.isCreateJSPlaying = false;
	
    this.init = function () {

        trace(":: Application Controller Initialized and Ready for task ::");
		
		/* var iPhone = /|iPhone|/.test(navigator.userAgent) && !window.MSStream;

		if(iPhone){ $(".mobile_footer").show() ; }; */
		
		$(".mobile_footer").css('bottom','0px');
		
        currentRef.audioManager = new AudioManager();
		currentRef.popupAudioManager = new PopupAudioManager();

        EventManager.getInstance().addControlEventListener(window, StaticLibrary.AUDIO_ENDED_EVENT, currentRef.audioEndEventHandler);

        $("#menuBoxContainer").hide();
        $("#parentContainerParent").hide();
        currentRef.controlVisibility("landingPage");

        var tocURL = _model.getCourseDataObj().baseURL + _model.getCourseDataObj().contentURL + "?version=" + StaticLibrary.generateRandom();
        trace("Course TOC : " + tocURL);
		
        trace(":: Course Table of Content, loading started ::");
        var apiServiceLoadAppData = new APIService();
        apiServiceLoadAppData.loadTOCData(tocURL, "true", StaticLibrary.DATA_TYPE, null, this.loadTOCSuccessHandler);
		
		currentRef.audioManager.stopAudio();
		currentRef.popupAudioManager.stopAudio();
		
		currentRef.popupAudioManager.loadAudio("assets/media/audio/blank");
        currentRef.audioManager.loadAudio("assets/media/audio/blank");
		
    }

    this.loadTOCSuccessHandler = function (data) {

        trace(":: Course Table of Content, loading Completed ::");
        DataParser.parseTOCData(data);
		
		for (var i = 0; i < _model.getLinearTOCDataArr().length; i++) {
            currentRef.menuStatusArr.push({"status":"NOT_STARTED"});
			if (_model.getLinearTOCDataArr()[i].pages != undefined) {
				currentRef.menuStatusArr[i].pages = new Array();
				for (var j = 0; j < _model.getLinearTOCDataArr()[i].pages.length; j++) {
					currentRef.menuStatusArr[i].pages.push({isVisited:"false",score:0});
				}
			}
		}	
		
		if( _model.getAppDataObj().scorm == "local" ){
			var storedCourseObj = localStorage.getItem(_model.getAppDataObj().courseName+'_v3');
			if( storedCourseObj != null ){
				var storedData = JSON.parse( storedCourseObj );			
				currentRef.courseTrackObj = storedData;
				currentRef.menuStatusArr = storedData.menuStatusArr;
				//_model.setLinearTOCDataArr(storedData);
			}
		}else if( _model.getAppDataObj().scorm == "scorm" ){
			var courseTrackingData = _model.getScormReference().retrieveTrackingData();
			
			//console.log(courseTrackingData);
			//console.log(typeof courseTrackingData);
			
			if (courseTrackingData != "") {
				//console.log('Entered');
				var curData = JSON.parse( courseTrackingData );	
				currentRef.courseTrackObj = curData;
				currentRef.menuStatusArr = curData.menuStatusArr;
				//_model.setLinearTOCDataArr(curData);
			}
		}

        trace(":: Course Table of Content, data parsing Completed ::");
        trace( _model.getLinearTOCDataArr() );

        //Logic for loading and painting the TOC in the shell.
        var menuStr = "";
		var courseMenustr = '';
        $("#menuContainerList").html('');

        //painting TOC Menu Titles when TOC Data loading is completed
        for (var i = 0; i < _model.getLinearTOCDataArr().length; i++) {
            if (_model.getLinearTOCDataArr()[i].pages != undefined) {
                menuStr += '<li data-toggle="collapse" data-target="#inner_' + i + '" aria-expanded="false" class="slidemenu collapsed enableArrow"><p class="nopad">' + _model.getLinearTOCDataArr()[i].pageTitle + '</p><ul class=" collapse" aria-expanded="false" id="inner_' + i + '"></ul></li> ';
            } else {
                menuStr += '<li class="eventcls"><p>' + _model.getLinearTOCDataArr()[i].pageTitle + '</p></li> ';
            }
			
			if(_model.getLinearTOCDataArr()[i].duration != undefined){
				courseMenustr+= '<li data-status='+currentRef.menuStatusArr[i].status+'><div class="menu_icons"><img class="icon_menu unlock_icon" src="assets/images/un_lock.png" alt=""/> <img class="icon_menu completed_icon" src="assets/images/tick_icon.png" alt=""/> <img class="icon_menu progress_icon" src="assets/images/progress_icon.png" alt=""/> <img class="icon_menu lock_icon" src="assets/images/lock.png" alt=""/></div><h3>'+_model.getLinearTOCDataArr()[i].pageTitle+'</h3><p class="duration">'+_model.getLinearTOCDataArr()[i].duration+'</p></li>'
			}
			
			trace(_model.getLinearTOCDataArr()[i].pageTitle);
			trace(_model.getLinearTOCDataArr()[i].duration);
        }
		
		$("#chapterMenu").html(courseMenustr);
		$(".icon_menu").hide();
		
		currentRef.updateModuleMenuStatus();
					
		$("#chapterMenu li").on('click',currentRef.chapterClickHandler);
		
        $("#menuContainerList").html(menuStr).promise().done(function () {

            trace(":: Menu Painted in the Container and event attached ::");

            for (var b = 0; b < _model.getLinearTOCDataArr().length; b++) {
                if (_model.getLinearTOCDataArr()[b].pages != undefined) {
                    for (var c = 0; c < _model.getLinearTOCDataArr()[b].pages.length; c++) {
						if(currentRef.menuStatusArr[b].pages[c].isVisited == "true"){
							if(!$(".menu_active i").hasClass("pull-right")){
								 $("#inner_" + b).append('<li data-chapter='+b+' data-page='+c+' class="eventcls completed" ><i class="fa fa-check-circle text-default pull-right"></i>' + _model.getLinearTOCDataArr()[b].pages[c].pageTitle + '</li>');
							}
						}else{
							 $("#inner_" + b).append('<li data-chapter='+b+' data-page='+c+' class="eventcls" >' + _model.getLinearTOCDataArr()[b].pages[c].pageTitle + '</li>');
						}
                    }
                }
            }

            $(".slidemenu").unbind("click").bind("click", currentRef.menuHeadColorClickHandler);

            $(".eventcls").each(function (a) {
                $(this).attr("id", "menuItem_" + a);
            })

            for (var e = 0; e < _model.getTOCDataArr().length; e++) {
                $("#menuItem_" + e).unbind("click").bind("click", currentRef.menuItemClickHandler);
            }

            /***************** Making menu Linear ******************/
            if (_model.getAppDataObj().linear == "true") {
                $(".eventcls").css({'pointer-events': 'none', 'opacity': 0.5}); // making all li to pointer event none first
				$(".completed").css({'pointer-events': 'auto', 'opacity': 1});
				
            }

            /* if (_model.getAppDataObj().scorm == "scorm") {
                for (var e = 0; e < _model.getTOCDataArr().length; e++) {
                    if (currentRef.menuStatusArr[e].isVisited == "true") {
                        $("#menuItem_" + e).css({'pointer-events': 'auto', 'opacity': 1}); // Enable Menu items for the completed screens.
                    }
                }
            } */
        });

        var glossaryURL = _model.getCourseDataObj().baseURL + "assets/data/content/glossary.json?version=" + StaticLibrary.generateRandom();
        trace("Glossary URL : " + glossaryURL);

        trace(":: Glossary data loading started ::");
        var apiServiceLoadAppData = new APIService();
        apiServiceLoadAppData.loadTOCData(glossaryURL, "true", StaticLibrary.DATA_TYPE, null, currentRef.loadGlossarySuccessHandler);

		currentRef.startClickHandler();
    }

    this.menuHeadColorClickHandler = function () {
        if($(this).find('.nopad').hasClass('clrtag')){
            $(this).find('.nopad').removeClass('clrtag');
        }else{
            $(this).find('.nopad').addClass('clrtag');
        }
    }

    this.loadGlossarySuccessHandler = function (data) {

        trace(":: Glossary data loading Completed ::");
        trace(data);

        //to-do task for loading and painting the Glossary in Glossary Popup.
        var glossaryController = new GlossaryController();
        glossaryController.init(data);

        currentRef.createResourcesPopup(_model.getCourseDataObj().resources);
        //currentRef.createHandoutPopup(_model.getCourseDataObj().handouts);
		
		/* var apiServiceLoadAppData = new APIService();
		var landingPageURL = _model.getCourseDataObj().baseURL +"pages/landingPage.html";
        apiServiceLoadAppData.loadFromExternalSource(landingPageURL, "true", StaticLibrary.TEMPLATE_TYPE, null, currentRef.landingPageSuccessHandler); */
	}
	
	this.landingPageSuccessHandler = function(data){
		$("#landingPage").html('').html(data).promise().done(function(){
			trace(":: Click start button to start the course, TOC loading and Painting completed ::");
			$("#btnStart").unbind("click").bind("click", currentRef.startClickHandler);
		});
	}	

    //function to crate Resource Link for the Resource Popup
    this.createResourcesPopup = function (resourceData) {
        trace(":: Creating Resource Popup ::");

        var resourceStr = "";
        $("#resourcePopupLinkContainer").html('');
		if(resourceData.length > 0){
			for (var i = 0; i < resourceData.length; i++) {
				resourceStr += "<p><a target='_blank' href='" + _model.getCourseDataObj().baseURL + "assets/data/resources/" + resourceData[i].url + "'>" + resourceData[i].title + "</a></p>";
			}
		} else {
				resourceStr = "There are no resources for this module.";
		}
        $("#resourcePopupLinkContainer").html(resourceStr);
    }

    //function to crate Handout Link for the Handout Popup
    this.createHandoutPopup = function (resourceData) {
        trace(":: Creating Handout Popup ::");
        var url = _model.getCourseDataObj().baseURL + "assets/data/handouts/" + resourceData[0].url;
        window.open(url);
    }

    this.startClickHandler = function () {
        trace(":: Start Course Button is clicked ::");
		
		/* if (_model.getAppDataObj().scorm == "scorm") {
                var isContinue = false;
				var completedScreenCount = 0;
				var totalScreenCount = 0;
				
				for(var i=0;i<currentRef.menuStatusArr.length;i++){
					if(currentRef.menuStatusArr[i].pages != undefined){
						for(var j=0;j<currentRef.menuStatusArr[i].pages.length;j++){
							totalScreenCount++;
							if(currentRef.menuStatusArr[i].pages[j].isVisited == "true"){
								completedScreenCount++;
							}
						}
					}
				}
				
				if( (completedScreenCount > 0) && ( totalScreenCount != completedScreenCount ) ){
				
                //if (_model.getScormReference().retrieveVisitedScreenNo() != "") {
                    isContinue = confirm("Do you want to continue the course from where you left ?");
                //}
				
				}
				
                if(isContinue){
					currentRef.curChapterIndex = currentRef.courseTrackObj.curChapterIndex;
					currentRef.curPageIndex = currentRef.courseTrackObj.curPageIndex;
					currentRef.currentIndex = currentRef.courseTrackObj.currentIndex;
					currentRef.startTheCourse();
					return;
                }
        } */
		
        currentRef.controlVisibility("innerContainer");
		$("#menuPart").css({'pointer-events': 'none', 'opacity': 0.5}); // Added to hide menu parts
		$("#footerSection_1").css({'pointer-events': 'none', 'opacity': 0.5});
        $("#menuBoxContainer").show();
        $("#headerSection_1").show();$("#headerSection_2").hide();
        $("#footerSection_2").hide();$("#parentContainerParent").hide();
        $("#playPauseBtn img").attr('src', 'assets/images/player_control_play_normal.png');
		currentRef.startTheCourse();
    }

	/* this.homeButtonClickHandler = function(){
		$("#audioPopup").hide();
		$("#mobileMenuOverlay").hide();
		$("#footerSection_2").hide();
		$("#nextNotification").hide();
		$("#menuPart").css({'pointer-events': 'none', 'opacity': 0.5});
		$("#footerSection_1").css({'pointer-events': 'none', 'opacity': 0.5});
        $("#playPauseBtn").attr('src', 'assets/images/player_control_play_normal.png');
		$("#menuBoxContainer").show();
        $("#headerSection_2").hide();
		$("#audioPopup").css("display", "none");
		$("#parentContainerParent, #pageJump").hide();
		$("#parentContainer").html('');
		$("#playPauseBtn, #audioMuteBtn").css("pointer-events","none");
		currentRef.updateModuleMenuStatus();
        currentRef.audioManager.stopAudio();
		currentRef.popupAudioManager.stopAudio();
	} */
	
    this.startTheCourse = function(){
		
		$("#pageJump").show();
		$("#menuPart").css({'pointer-events': 'auto', 'opacity': 1});
		$("#footerSection_1").css({'pointer-events': 'auto', 'opacity': 1});
        $("#menuBoxContainer").hide();
        $("#headerSection_2").show();
        $("#footerSection_2").show();$("#parentContainerParent").show();
		$("#nextNotification").show();
		$(".nextContinue").hide();
		
		//$(".instructionBtn").css({'pointer-events':'none','opacity':'0.5'});
 
		if( /Android|iPhone|iPod/i.test(navigator.userAgent) ) {
			$("#headerSection_1").show();
			$("#headerSection_2").hide();
		}
        
		currentRef.checkChapterCompletionStatus();

        setTimeout(function(){
            $("#previousBtn").unbind("click").bind("click", currentRef.previousClickHandler);
            $("#nextBtn").unbind("click").bind("click", currentRef.nextClickHandler);
            $("#audioMuteBtn").unbind("click").bind("click", currentRef.muteUnMuteHandler);
            $("#playPauseBtn").unbind("click").bind("click", currentRef.playPauseClickHandler);
            $("#replyBtn").unbind("click").bind("click", currentRef.replyClickHandler);

            $("#courseMenuBtn").unbind("click").bind("click", currentRef.courseMenuClickHandler);
            $("#resourceBtn").unbind("click").bind("click", currentRef.resourceClickHandler);
            $("#referenceBtn").unbind("click").bind("click", currentRef.referenceClickHandler);
            $("#glossaryBtn").unbind("click").bind("click", currentRef.glossaryClickHandler);
            $(".instructionBtn").unbind("click").bind("click", currentRef.helpClickHandler);
            $("#handoutBtn").unbind("click").bind("click", currentRef.handoutClickHandler);
            $("#transcriptBtn").unbind("click").bind("click", currentRef.transcriptClickHandler);
            $("#notesClose").unbind("click").bind("click", currentRef.audioTranscriptCloseHandler);
            //$("#homeMenuBtn").unbind("click").bind("click", currentRef.homeButtonClickHandler);
            $("#jumpToTxt").bind('keyup',  currentRef.jumpToSubmitHandler);
            $("#jumpToBtn").unbind("click").bind("click", currentRef.jumpToBtnHandler);
 			$("#menu_close").unbind("click").bind("click", currentRef.headerPopupCloseHandler);
			$("#resourcePopup, #helpPopup, #glossaryPopup, #referencePopup, #resourcePopup").on("hidden.bs.modal", currentRef.headerPopupCloseHandler);	 	  	
			$(".mobile_footer").unbind("click").bind("click", currentRef.mobileFoooterMenuOpenHandler);
			$(".footer_close_icon").unbind("click").bind("click", currentRef.mobileFoooterMenuCloseHandler);
			$("#ccTextBtn").unbind("click").bind("click", currentRef.ccTextClickHandler);
			$(".menu_click_bg").unbind("click").bind("click", currentRef.mobileMenuHandler);
			$(".mobile_menus").css({'display':'none','right':'-148px'});
			
			$(".glossaryBtn").css({'pointer-events':'none','opacity':0.5});
			$(".homeBtn").unbind("click").bind("click", currentRef.homeButtonClickHandler);
			
			//$("#ccTextBtn").trigger('click');
				
            currentRef.controlVisibility("innerContainer");
            currentRef.loadCurrentPage(currentRef.currentIndex);
        }, 200);
    }
	
	this.homeButtonClickHandler = function(){
		location.reload();	
	}
	
	this.jumpToSubmitHandler = function(event){
		if(event.keyCode == 13){ 
			event.preventDefault();
			$("#jumpToBtn").click(); 
			return false;
		}
	}
	
	this.jumpToBtnHandler = function(){
		trace("Jump To Page : " + $("#jumpToTxt").val());
		var totalPages = _model.getTOCDataArr().length;
		var jumpToPage = (parseInt($("#jumpToTxt").val()) - 1);
		if((jumpToPage < totalPages) && (jumpToPage >= 0)){
			
			currentRef.curChapterIndex = $("#menuItem_"+jumpToPage).attr('data-chapter');
			currentRef.curPageIndex = $("#menuItem_"+jumpToPage).attr('data-page');
			
			currentRef.currentIndex = jumpToPage;
			currentRef.loadCurrentPage(currentRef.currentIndex);
		} else {
			alert("Incorrect page number.");
		}
	}
	
	 this.mobileMenuHandler = function () {
        if ($(".mobile_menus").css("display") == "block") {
			$("#mobileMenuOverlay").hide();
			if(currentRef.playPauseFlag == true){
				currentRef.audioManager.playAudio();
			}
            $(".mobile_menus").animate({'position': 'absolute', 'right': '-148px'}, 500, function () {
                $(".mobile_menus").hide();
				//$(".disableMenuBG").hide();
            });
        } else {
			$("#mobileMenuOverlay").show();
				currentRef.audioManager.pauseAudio();
            $(".mobile_menus").show(1, function () {
				//$(".disableMenuBG").show();
                $(".mobile_menus").animate({'position': 'absolute', 'right': '0px'}, 500);
            });

        }
    };
	
    this.mobileFoooterMenuOpenHandler = function () {
       $('.container-fluid').addClass('add_footer');
    };
	
	this.mobileFoooterMenuCloseHandler = function () {
       $('.container-fluid').removeClass('add_footer');
    };
	
	this.ccTextCloseHandler = function(){
		$(".cc_text").hide();	
		//$("#ccTextBtn img").attr('src','assets/images/player_control_cc_normal.png');	
	}
	
	this.ccTextClickHandler = function(){
		if( !currentRef.isCCTextPlaying ){
			$(".cc_text").show();	
			$("#ccTextBtn img").attr('src','assets/images/player_control_cc_active.png');
			currentRef.isCCTextPlaying = true;
		}else{
			$(".cc_text").hide();	
			$("#ccTextBtn img").attr('src','assets/images/player_control_cc_normal.png');
			currentRef.isCCTextPlaying = false;
		}
	}

	this.ccTextShowHandler = function() {
		if (currentRef.isCCTextPlaying) {
			$(".cc_text").show();
		} else {
			$(".cc_text").hide();
		}
	}
		
    this.menuItemClickHandler = function (event) {
		$("#mobileMenuOverlay").hide();
		event.stopPropagation();
		
        var str = event.currentTarget.id;
        var tempIndexArr = str.split("_");

        currentRef.curChapterIndex = $(this).attr('data-chapter');
		currentRef.curPageIndex = $(this).attr('data-page');
		
        currentRef.currentIndex = parseInt(tempIndexArr[1]);
		currentRef.loadCurrentPage(currentRef.currentIndex);

        $("#menuContainer").modal('hide');
    }
	
	
    //function to handle the previous button click to load previous pages in the shell
    this.previousClickHandler = function () {

        trace(":: Previous Button Clicked ::");
		
        if (currentRef.currentIndex <= 0) {
            trace(":: Your on First Page ::");
        } else {
		
			if(currentRef.curPageIndex > 0){
				currentRef.curPageIndex--;
			}else{
				var  totalChapterLength = _model.getLinearTOCDataArr().length-1;
				if(currentRef.curChapterIndex > 0){
					currentRef.curChapterIndex--;
					var curChapterPagesLength = _model.getLinearTOCDataArr()[currentRef.curChapterIndex].pages.length-1;
					currentRef.curPageIndex	= curChapterPagesLength;				
				}
			}
			
			trace("curChapterPagesLength: "+curChapterPagesLength+"  currentRef.curChapterIndex: "+currentRef.curChapterIndex+" currentRef.curPageIndex: "+currentRef.curPageIndex);
			
			
			currentRef.currentIndex--;
            currentRef.loadCurrentPage(currentRef.currentIndex);
			currentRef.ccTextShowHandler();
        }
    }

    //function to handle the next button click to load next pages in the shell
    this.nextClickHandler = function () {

        trace(":: Next Button Clicked ::");

		$('.container-fluid').removeClass('add_footer');

		currentRef.ccTextShowHandler();
		
        var totalLength = _model.getTOCDataArr().length;
        if (currentRef.currentIndex >= (totalLength - 1)) {
           trace(":: Your on Last Page ::"); 
            /* if (_model.getAppDataObj().scorm == "scorm") {
                _model.getScormReference().storeCompletionStatus("completed");
            } */
        } else {
            
			// Traversal Start
			
			if( _model.getLinearTOCDataArr()[currentRef.curChapterIndex].pages != undefined ){
				
				var curChapterPagesLength = _model.getLinearTOCDataArr()[currentRef.curChapterIndex].pages.length-1;
				var  totalChapterLength = _model.getLinearTOCDataArr().length-1;
				
				if(curChapterPagesLength  >  currentRef.curPageIndex){
					currentRef.curPageIndex++;
				}else{
					if(totalChapterLength > currentRef.curChapterIndex){
						trace( _model.getLinearTOCDataArr() );
						currentRef.menuStatusArr[currentRef.curChapterIndex].status = "COMPLETED";
						currentRef.curChapterIndex++;
						if(currentRef.menuStatusArr[currentRef.curChapterIndex].status == "NOT_STARTED"){
							currentRef.menuStatusArr[currentRef.curChapterIndex].status = "IN_PROGRESS";
						}
						currentRef.curPageIndex	= 0;				
					}
				}
				
				var curChapterPagesLength = _model.getLinearTOCDataArr()[currentRef.curChapterIndex].pages.length-1;
				
				if( (curChapterPagesLength == currentRef.curPageIndex) && (totalChapterLength == currentRef.curChapterIndex) ){
					currentRef.menuStatusArr[currentRef.curChapterIndex].status = "COMPLETED";
				}
				
				trace("totalChapterLength: "+totalChapterLength+" curChapterPagesLength: "+curChapterPagesLength+"  currentRef.curChapterIndex: "+currentRef.curChapterIndex+" currentRef.curPageIndex: "+currentRef.curPageIndex);
				
		    }
			
			
			// Traversal End
			
			currentRef.currentIndex++;
            currentRef.loadCurrentPage(currentRef.currentIndex);
        }
    }

    //function to handle mute and un-mute of audio in the framework
    this.muteUnMuteHandler = function () {

        trace(":: Mute Unmute Button Clicked ::");

			if (currentRef.audioMuteFlag) {
				currentRef.audioManager.muteAudio();
				currentRef.popupAudioManager.muteAudio();
				$("#audioMuteBtn img").attr('src', 'assets/images/player_control_audio_active.png');
				currentRef.audioMuteFlag = false;
			} else {

				currentRef.audioManager.unMuteAudio();
				currentRef.popupAudioManager.unMuteAudio();
				$("#audioMuteBtn img").attr('src', 'assets/images/player_control_audio_normal.png');
				currentRef.audioMuteFlag = true;
			}
		
    }

    //function to handle play and pause on the framework level.
    this.playPauseClickHandler = function () {

        trace(":: Play Pause Button ::");
		
		/* if(currentRef.isCreateJSPlaying){
				
		} */
		
		if(currentRef.isMainAudioPlaying){
			if (currentRef.playPauseFlag) {
				currentRef.playPauseFlag = false;
				currentRef.audioManager.pauseAudio();
				if(currentRef.createJSRef != ''){
					//createjs.Ticker.setPaused(true);
					currentRef.createJSRef.stop();	
				}
				$("#playPauseBtn img").attr('src', 'assets/images/player_control_play_normal.png');
			} else {
				currentRef.playPauseFlag = true;
				currentRef.audioManager.playAudio();
				if(currentRef.createJSRef != ''){
					//createjs.Ticker.setPaused(false);
					currentRef.createJSRef.play();	
				}
				$("#playPauseBtn img").attr('src', 'assets/images/player_control_pause_normal.png');
			}
		} 
			
		if(currentRef.isPopupAudioPlaying){
			if (currentRef.popupAudioplayPauseFlag) {
				currentRef.popupAudioplayPauseFlag = false;
				currentRef.popupAudioManager.pauseAudio();
				if(currentRef.createJSRef != ''){
					//createjs.Ticker.setPaused(true);
					currentRef.createJSRef.stop();	
				}
				$("#playPauseBtn img").attr('src', 'assets/images/player_control_play_normal.png');
			} else {
				currentRef.popupAudioplayPauseFlag = true;
				currentRef.popupAudioManager.playAudio();
				if(currentRef.createJSRef != ''){
					//createjs.Ticker.setPaused(false);
					currentRef.createJSRef.play();	
				}
				$("#playPauseBtn img").attr('src', 'assets/images/player_control_pause_normal.png');
			}	
		}
    }

    //function to handle the reply of the current loaded page in the shell.
    this.replyClickHandler = function () {
        trace(":: Reply Button Click ::");
        currentRef.loadCurrentPage(currentRef.currentIndex);
		if ($(".system_menu").css("display") == "block") {
            $(".system_menu").animate({'position': 'absolute', 'right': '-168px'}, 500, function () {
               // $(".system_menu").hide();
            });
        }
		currentRef.ccTextShowHandler();
		 $(".disableMenuBG").hide();
    }

    //function to handle the click event for menu button from the shell
    this.courseMenuClickHandler = function () {
        trace(":: Menu Button Clicked ::");
        $("#menuContainer").modal('show');
		currentRef.audioManager.pauseAudio();
		currentRef.courseMenuHideHandler();
		$("#videoTemplateContainer").trigger('pause');
		$(".disableMenuBG").hide();
    }
 
	this.headerPopupCloseHandler = function(){
		trace(":: Menu Button Close Handler ::");
		$("#mobileMenuOverlay").hide();
 		 $("#videoTemplateContainer").trigger('play');
		 
		if(currentRef.playPauseFlag == false){
			currentRef.audioManager.unMuteAudio();
		}else{
			currentRef.audioManager.playAudio();
		}
	}
	
    //function to handle the click event for Resource button from the shell
    this.resourceClickHandler = function () {
        trace(":: Resource Button Clicked ::");
		currentRef.courseMenuHideHandler();
		currentRef.audioManager.pauseAudio();
 		$("#videoTemplateContainer").trigger('pause');
		$(".disableMenuBG").hide();
    }
	
	//function to handle the click event for Resource button from the shell
    this.referenceClickHandler = function () {
        trace(":: Reference Button Clicked ::");
		currentRef.courseMenuHideHandler();
		$("#videoTemplateContainer").trigger('pause');
		currentRef.audioManager.pauseAudio();
		$(".disableMenuBG").hide();
    }

    //function to handle the click event for Glossary button from the shell
    this.glossaryClickHandler = function () {
        trace(":: Glossary Button Clicked ::");
		currentRef.courseMenuHideHandler();
		$("#videoTemplateContainer").trigger('pause');
		 currentRef.audioManager.pauseAudio();
		 $(".disableMenuBG").hide();
    }

    //function to handle the click event for Help button from the shell
    this.helpClickHandler = function () {
        trace(":: Help Button Clicked ::");
		//currentRef.courseMenuHideHandler();
		//$("#videoTemplateContainer").trigger('pause');
		
		/* if(currentRef.isMainAudioPlaying){
			if (currentRef.playPauseFlag) {
				currentRef.playPauseFlag = false;
				currentRef.audioManager.pauseAudio();
				$("#playPauseBtn").attr('src', 'assets/images/player_control_play_normal.png');
			} else {
				currentRef.playPauseFlag = true;
				currentRef.audioManager.playAudio();
				$("#playPauseBtn").attr('src', 'assets/images/player_control_pause_normal.png');
			}
		} 
			
		if(currentRef.isPopupAudioPlaying){
			if (currentRef.popupAudioplayPauseFlag) {
				currentRef.popupAudioplayPauseFlag = false;
				currentRef.popupAudioManager.pauseAudio();
				$("#playPauseBtn").attr('src', 'assets/images/player_control_play_normal.png');
			} else {
				currentRef.popupAudioplayPauseFlag = true;
				currentRef.popupAudioManager.playAudio();
				$("#playPauseBtn").attr('src', 'assets/images/player_control_pause_normal.png');
			}
		} */
		
		if( $(".helpBgcolor").css('display') == 'none' ){
			//$('.footer_part').hide();
			$('.container-fluid').addClass('footer_disable');
			$(".helpBgcolor").show();	
			$(".help_img").addClass('active');
			
			if(currentRef.isMainAudioPlaying){
				currentRef.playPauseFlag = false;
				currentRef.audioManager.pauseAudio();
				$("#playPauseBtn img").attr('src', 'assets/images/player_control_play_normal.png');
			}
			
			if(currentRef.isPopupAudioPlaying){
				currentRef.popupAudioplayPauseFlag = false;
				currentRef.popupAudioManager.pauseAudio();
				$("#playPauseBtn img").attr('src', 'assets/images/player_control_play_normal.png');
			}
			
		}else{
			//$('.footer_part').show();	
			$('.container-fluid').removeClass('footer_disable');
			$(".helpBgcolor").hide();
			$(".help_img").removeClass('active');
			
			if(currentRef.isMainAudioPlaying){
				currentRef.playPauseFlag = true;
				currentRef.audioManager.playAudio();
				$("#playPauseBtn img").attr('src', 'assets/images/player_control_pause_normal.png');
			}
			
			if(currentRef.isPopupAudioPlaying){
				currentRef.popupAudioplayPauseFlag = true;
				currentRef.popupAudioManager.playAudio();
				$("#playPauseBtn img").attr('src', 'assets/images/player_control_pause_normal.png');
			}
			
		}
		
		$("#mobileMenuOverlay").hide();

        $(".mobile_menus").animate({'position': 'absolute', 'right': '-148px'}, 500, function () {
            $(".mobile_menus").hide();
			//$(".disableMenuBG").hide();
        });
		
		$(".mobile_menus .instructionBtn").addClass('active');
		
		//$(".helpBgcolor").toggle();
		//$(".disableMenuBG").hide();
    }
	this.courseMenuHideHandler = function () {
		if($( window ).width() <= 480){
			$(".system_menu").css({'right':'-148px','display':'none'});
		}
	}

    //function to handle the click event for Handout button from the shell
    this.handoutClickHandler = function () {
        trace(":: Handout Button Clicked ::");
        currentRef.createHandoutPopup(_model.getCourseDataObj().handouts);
    }

    //function to handle the click event for Transcript button from the shell
    this.transcriptClickHandler = function () {

        trace(":: Transcript Button Clicked ::");
		if ($(".system_menu").css("display") == "block") {
            $(".system_menu").animate({'position': 'absolute', 'right': '-168px'}, 500, function () {
                //$(".system_menu").hide();
            });
        }
		 //$(".disableMenuBG").hide();
		$(".audio_Popup").show();
		$("#transcriptBtn img").attr('src','assets/images/player_control_transcript_active.png');
    }
	
	this.audioTranscriptCloseHandler = function(){
		$(".audio_Popup").hide();
		$("#transcriptBtn img").attr('src','assets/images/player_control_transcript_normal.png');
	}

    //function gets triggered whenever the audio is completed play in the shell.
    this.audioEndEventHandler = function (data) {
        trace("::  Audio Ended & Click  from the Templates for Notification ::");
		
		trace(data.obj)

        currentRef.playPauseFlag = false;
		currentRef.isMainAudioPlaying = false;
		
        //currentRef.menuStatusArr[currentRef.currentIndex].isVisited = "true";
		
		
		if(data.obj != null){
			trace(data.obj.type);	
			if(data.obj.type == "assessment"){
				currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.curPageIndex].score = data.obj.score;
			}
		}
		
		if($("#parentContainer").hasClass("anchorTag")){
				var local = parseInt(currentRef.currentIndex) + parseInt(1);
				localStorage.setItem("anchor_slide_"+local+"","true");
						$("#parentContainer").removeClass("anchorTag");
		}
		
		var totalScore = 0;
		var totalQuestions = 0;
		
		/* for(var i=0;i<currentRef.menuStatusArr.length;i++){
			if( currentRef.menuStatusArr[i].pages != undefined ){
				for(var j=0;j<currentRef.menuStatusArr[i].pages.length;j++){
					 var curScreenScore = currentRef.menuStatusArr[i].pages[j].score;
					if( ( _model.getLinearTOCDataArr()[i].pages[j].templateName == "MultipleChoiceMultiSelectTemplate" ) || ( _model.getLinearTOCDataArr()[i].pages[j].templateName == "MultipleChoiceSingleSelectTemplate" ) || (_model.getLinearTOCDataArr()[i].pages[j].templateName == "TrueandFalseTemplate") ){
						totalQuestions++;
					}
					
					if( ( _model.getLinearTOCDataArr()[i].pages[j].templateName == "VideoTemplate" )  || ( _model.getLinearTOCDataArr()[i].pages[j].templateName == "ModuleVideoTemplate" ) ){
						$("#videoTemplateContainer").trigger('play');
						$('#videoTemplateContainer').attr('controls', true);
					}

					//if(curScreenScore){
						totalScore += curScreenScore;
					//} 
				}
			}
		} */

		scoreInPercentage = (totalScore/totalQuestions)*100;
		scoreInPercentage = Math.round(scoreInPercentage);
		
		currentRef.scoreInPercentage = scoreInPercentage;
		
		trace("totalScore: "+totalScore+" totalQuestions: "+totalQuestions+" scoreInPercentage: "+scoreInPercentage)
		
        /************** Making menu Linear starts*******************/

        trace((_model.getAppDataObj().linear == "true") + " - " + (_model.getTemplateStatus()) + " - " + (_model.getAudioStatus()))

        var lastPage = _model.getTOCDataArr().length - parseInt(1);
        if(currentRef.currentIndex == lastPage){
            $(" #menuItem_"+lastPage+" ").css({'pointer-events': 'auto', 'opacity': 1});
            /************** Making menu Linear ends*******************/
        }

		
		
		
        if(_model.getAudioStatus()){
            $("#playPauseBtn img").attr('src', 'assets/images/player_control_play_normal.png'); // added to change play icon when audio ends
        }

		if ((_model.getAppDataObj().linear == "false") && (_model.getAudioStatus() && _model.getTemplateStatus() )) {
			//added to control the next notification after audio ends
			 if(currentRef.currentIndex < lastPage){
				$(".nextContinue").fadeIn(800);
				$("#nextBtn").addClass('blink_it');
				$('.container-fluid').addClass('add_footer');
			 }
			//added to control tick mark in menus
		}
		
		console.log( (_model.getTemplateStatus()) + "  " + (_model.getAudioStatus()) )
		
		
		//$("#popupCloseButton").show();
		
        if ((_model.getAppDataObj().linear == "true") && (_model.getTemplateStatus()) && (_model.getAudioStatus())) {
            _model.setTemplateStatus(false);
            _model.setAudioStatus(false); 
            var nextPage = currentRef.currentIndex + parseInt(1);
			
            // making next li to active after audio ends
            $(" #menuItem_"+currentRef.currentIndex+" , #menuItem_"+nextPage+"").css({'pointer-events': 'auto', 'opacity': 1}); 
			$(" #menuItem_"+currentRef.currentIndex+" , #menuItem_"+nextPage+"").addClass('completed'); 
            
			
			if(currentRef.currentIndex < lastPage){
				//added to control the next notification after audio ends
				//$("#nextNotification").fadeIn(800);
				$(".nextContinue").fadeIn(800);
				$("#nextBtn").addClass('blink_it');
				$('#nextBtn').css({'pointer-events': 'auto', 'opacity': 1}); // enabled the next button when navigation is set to non-linear.
				$('.container-fluid').addClass('add_footer');
			}
			//added to control tick mark in menus
			if(!$(".menu_active i").hasClass("pull-right")){
				$(".menu_active").append('<i class="fa fa-check-circle text-default pull-right"></i>');
			}
			
			if( currentRef.menuStatusArr[currentRef.curChapterIndex].pages != undefined ){
				currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.curPageIndex].isVisited = "true";
				currentRef.checkChapterCompletionStatus();
			}
		
			currentRef.courseTrackObj.menuStatusArr = currentRef.menuStatusArr;
			currentRef.courseTrackObj.curChapterIndex = currentRef.curChapterIndex;
			currentRef.courseTrackObj.curPageIndex = currentRef.curPageIndex;
			currentRef.courseTrackObj.currentIndex = currentRef.currentIndex;
			
			$(".completed").css({'pointer-events': 'auto', 'opacity': 1});
		
        } else {
            trace("triggered");
        }
		
		if (_model.getAppDataObj().scorm == "scorm") {
			_model.getScormReference().storeTrackingData( JSON.stringify(currentRef.courseTrackObj) ); //Menu Status to LMS.
			
			var chapterCompletionCount = 0;
			
			for(var i=0;i<currentRef.menuStatusArr.length;i++){
				if(currentRef.menuStatusArr[i].status == "COMPLETED"){
					chapterCompletionCount++;	
				}
			}
			
			var completionStatus = _model.getScormReference().retrieveCompletionStatus();
			
			//console.log(completionStatus);
			
			if(completionStatus != 'passed'){
				//console.log(scoreInPercentage);
				//console.log(currentRef.currentIndex);
				//_model.getScormReference().storeAssessmentScore(scoreInPercentage);
				//if(chapterCompletionCount == currentRef.menuStatusArr.length){
				if(_model.getTOCDataArr()[currentRef.currentIndex].templateName == "CongratulationTemplate"){
					//console.log('Entered');
					_model.getScormReference().storeAssessmentScore(scoreInPercentage);
					_model.getScormReference().storeCompletionStatus(scoreInPercentage);
				}
			}else{
				/* if(chapterCompletionCount == currentRef.menuStatusArr.length){
					_model.getScormReference().storeAssessmentScore(scoreInPercentage);
					_model.getScormReference().storeCompletionStatus();		
				} */
			}

        }else if(_model.getAppDataObj().scorm != "scorm"){
			localStorage.setItem(_model.getAppDataObj().courseName+'_v3',JSON.stringify(currentRef.courseTrackObj) );		
		}
    }

    this.loadCurrentPage = function (currentIndex) {
		
		//alert();
		
		$("#nextBtn").removeClass('blink_it');
		$("#helpBtn, #courseMenuBtn").css({"pointer-events":"auto", "opacity":"1"});
		$("#playPauseBtn, #audioMuteBtn").css({'pointer-events': 'auto', 'opacity': 1}); 
		$(".helpBgcolor").hide();	
		$(".model_body_inner").scrollTop(0);
		
        trace(":: Loading Current Request Page from Page Collection :: ");
	
        currentRef.playPauseFlag = true;
		currentRef.popupAudioplayPauseFlag = false;
		
		currentRef.isMainAudioPlaying = true;
		currentRef.isPopupAudioPlaying = false;
		
        StaticLibrary.SHOW_PRE_LOADER();
		currentRef.popupAudioManager.stopAudio();
        currentRef.audioManager.stopAudio();
		
		if(currentTemplateObj){
			currentTemplateObj.clear();
		}
		
		currentRef.courseTrackObj.menuStatusArr = currentRef.menuStatusArr;
		currentRef.courseTrackObj.curChapterIndex = currentRef.curChapterIndex;
		currentRef.courseTrackObj.curPageIndex = currentRef.curPageIndex;
		currentRef.courseTrackObj.currentIndex = currentRef.currentIndex;
		
		if (_model.getAppDataObj().scorm == "scorm") {
			_model.getScormReference().setSessionTime();
			_model.getScormReference().storeTrackingData( JSON.stringify(currentRef.courseTrackObj) ); //Menu Status to LMS.
		}else if(_model.getAppDataObj().scorm != "scorm"){
			localStorage.setItem(_model.getAppDataObj().courseName+'_v3',JSON.stringify(currentRef.courseTrackObj) );		
		}
		
		if( /iPhone|iPad|iPod/i.test(navigator.userAgent) ) {
			$("#audioMuteBtn").css({'pointer-events': 'none', 'opacity': 0.5});
		}
		
		$("#previousBtn").css({'pointer-events': 'auto', 'opacity': 1});
        _model.setTemplateStatus(false);
        _model.setAudioStatus(false);

		//added to control the next notification after audio ends
		$(".nextContinue").hide();
		//$("#nextNotification").hide();
		
        $("#playPauseBtn img").attr('src', 'assets/images/player_control_pause_normal.png'); // Added to act like pause button on page starts

       if (_model.getAppDataObj().linear == "true") {
            $('#nextBtn').css({'pointer-events': 'none', 'opacity': 0.5}); // disable the next button when navigation is set to linear.
        } else {
            $('#nextBtn').css({'pointer-events': 'auto', 'opacity': 1}); // enabled the next button when navigation is set to non-linear.
        }
		
		if ( currentRef.menuStatusArr[currentRef.curChapterIndex].pages != undefined ){
			if (currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.curPageIndex].isVisited == "true") {
				$('#nextBtn').css({'pointer-events': 'auto', 'opacity': 1});
			}
		}
		
        $("#parentContainer").html('');

        currentRef.currentPageToLoadObj = _model.getTOCDataArr()[currentIndex];
        currentRef.currentPageTranscript = currentRef.currentPageToLoadObj.transcript;

        trace(currentRef.currentPageToLoadObj);

        if (currentRef.currentPageToLoadObj.isLocal == "true") {
            trace(":: Only loading HTML page from base folder location ::");
            var htmlURL = _model.getCourseDataObj().baseURL + "pages/" + currentRef.currentPageToLoadObj.templateName + ".html?version=" + StaticLibrary.generateRandom();
            trace("HTML Page URL : " + htmlURL);
            var apiServiceLoadAppData = new APIService();
            apiServiceLoadAppData.loadFromExternalSource(htmlURL, "true", "html", null, currentRef.loadExternalPageSuccessHandler);

        } else {
            trace(":: Going to load JSON and on competition loading of HTML Pages started ::");
            var jsonURL = _model.getCourseDataObj().baseURL + "assets/data/content/" + currentRef.currentPageToLoadObj.templateJSON + "." + StaticLibrary.DATA_TYPE + "?version=" + StaticLibrary.generateRandom();
            trace("JSON Data URL : " + jsonURL);
            var apiServiceLoadAppData = new APIService();
            apiServiceLoadAppData.loadFromExternalSource(jsonURL, "true", StaticLibrary.DATA_TYPE, null, this.externalDataLoadHandler);
        }

        /************** Making menu Linear starts*******************/

        $("#menuContainerList li").removeClass("menu_active");
        $("#menuItem_" + currentRef.currentIndex).addClass("menu_active");

        if (_model.getAppDataObj().linear == "true") {
            $(".menu_active").css({'pointer-events': 'none', 'opacity': 1}); //making current page in menu not clickable
        }
        /************** Making menu Linear ends*******************/
	
		//making next button in last and first page to inactive state
		if (currentRef.currentIndex >= (_model.getTOCDataArr().length - 1)) {
			$("#nextBtn").css({'pointer-events': 'none', 'opacity': 0.5});
		}
		if (currentRef.currentIndex < 1){
			$("#previousBtn").css({'pointer-events': 'none', 'opacity': 0.5});
		}
		
		$(".completed").css({'pointer-events': 'auto', 'opacity': 1});
    }

    this.externalDataLoadHandler = function (data) {
        trace(":: External JSON Loading Completed ::");
        trace(data);

        _model.setCurrentPageDataObj(data);

        trace("Template Location : " + _model.getAppDataObj().templateLocation);
        trace("Template Name : " + currentRef.currentPageToLoadObj.templateName);

        var htmlURL = _model.getAppDataObj().templateLocation + currentRef.currentPageToLoadObj.templateName + ".html?version=" + StaticLibrary.generateRandom();
        trace("Template Page Location : " + htmlURL);

        trace(":: Loading HTML Template Started ::");
        var apiServiceLoadAppData = new APIService();
        apiServiceLoadAppData.loadFromExternalSource(htmlURL, "true", "html", null, currentRef.loadExternalPageSuccessHandler);
    }

    //Add all the template that needs to be involved in the Framework in the below Switch case.
    this.loadExternalPageSuccessHandler = function (pageHTMLStr) {

        trace(":: Loading HTML Template Completed ::");

		if ((_model.getAppDataObj().linear == "false")) {
			if(!$(".menu_active i").hasClass("pull-right")){
				$(".menu_active").append('<i class="fa fa-check-circle text-default pull-right"></i>');
			}
		}
		
        $("#parentContainer").html('').hide();
        $("#parentContainer").html(pageHTMLStr).promise().done(function () {

            trace(':: Page HTML content painted in the container ::');
			
            currentTemplate = currentRef.currentPageToLoadObj.templateName;
            currentTemplateObj;

            trace(currentTemplate);

            switch (currentTemplate) {	

				case "slide0":
                    currentTemplateObj = new slide0Controller(currentRef);
                break;

                case "slide1":
                    currentTemplateObj = new slide1Controller(currentRef);
                break;

                case "slide2":
                    currentTemplateObj = new slide2Controller(currentRef);
                break;

                case "slide3":
                    currentTemplateObj = new slide3Controller(currentRef);
                break;

                case "slide4":
                    currentTemplateObj = new slide4Controller(currentRef);
                break;
				
				case "slide5":
                    currentTemplateObj = new slide5Controller(currentRef);
                break;
				
                default:
                    trace(":: Template not found, please check with administrator ::");
                break;
            }

            currentTemplateObj.init(_model.getCurrentPageDataObj());

            $("#paginationTxt").html('');
			$("#paginationTxt").html('<span>'+ (currentRef.currentIndex + 1) +'</span><p>/ '+_model.getTOCDataArr().length+' </p>');
			
			var curPercentage = (currentRef.currentIndex+1) / _model.getTOCDataArr().length;
			
			$(".slider_marker").width( ( curPercentage * 100 ) + "%");

            $(".audio_Popup .model_body_inner").html('');
			
            if(currentTemplate !=  "CongratulationTemplate"){
				$(".audio_Popup .model_body_inner").html(_model.getTOCDataArr()[currentRef.currentIndex].transcript);
				$("#playPauseBtn img").attr('src', 'assets/images/player_control_pause_normal.png'); // Added to act like pause button on page starts
				trace("Audio Path : " + _model.getCourseDataObj().baseURL + "assets/media/audio/" + _model.getTOCDataArr()[currentRef.currentIndex].pageAudio);
				currentRef.audioManager.loadAudio(_model.getCourseDataObj().baseURL + "assets/media/audio/" + _model.getTOCDataArr()[currentRef.currentIndex].pageAudio);
				
				console.log( _model.getTOCDataArr()[currentRef.currentIndex].transcript );
				
			}else{
				currentRef.audioManager.clearAudio();
				StaticLibrary.HIDE_PRE_LOADER();
			}
			
			console.log( _model.getCurrentTime() )
        });
    }

    //function to control the visibility of the framework level page loading.
    this.controlVisibility = function (currentView) {

        trace("Current Visible Container : " + currentView);
        $("#landingPage").hide();
        $("#innerContainer").hide();
        $("#" + currentView).show();
    }
	
	//Check Chapter Completion Status
	this.checkChapterCompletionStatus = function(){
		var pageCompletionCount = 0;
		var chapterCompletionCount  = 0;
		if( currentRef.menuStatusArr[currentRef.curChapterIndex].pages.length != undefined ){
			for(var j=0;j<currentRef.menuStatusArr[currentRef.curChapterIndex].pages.length;j++){
				if(currentRef.menuStatusArr[currentRef.curChapterIndex].pages[j].isVisited == "true"){
						pageCompletionCount++;
				}
			}
			
			if(pageCompletionCount == currentRef.menuStatusArr[currentRef.curChapterIndex].pages.length){
				currentRef.menuStatusArr[currentRef.curChapterIndex].status = "COMPLETED";
			}
		}
		
		
		for(var i=0;i<currentRef.menuStatusArr.length;i++){
			if(currentRef.menuStatusArr[i].status == "COMPLETED"){
				chapterCompletionCount++;	
			}
		}

		if (_model.getAppDataObj().scorm == "scorm") {
           if(chapterCompletionCount == currentRef.menuStatusArr.length){
				//console.log('ALL CHAPTERS COMPLETED');
				//_model.getScormReference().storeCompletionStatus("completed");
				$("#pageJump").show();
			}else{
				$("#pageJump").hide();
			}
        }
	}
	
	//update module status
	this.updateModuleMenuStatus = function(){
		for (var i = 0; i < _model.getLinearTOCDataArr().length; i++) {
			if(_model.getLinearTOCDataArr()[i].duration != undefined){
				if( currentRef.menuStatusArr[i].status == 'NOT_STARTED' ){
					if( _model.getAppDataObj().linear == "true" ){
						if(i == 0){
							$("#chapterMenu").children().eq(i).find('.unlock_icon').show();	
						}else{
							$("#chapterMenu").children().eq(i).find('.lock_icon').show();
						}
					}else{
						$("#chapterMenu").children().eq(i).find('.unlock_icon').show();
					}
				}else if( currentRef.menuStatusArr[i].status == 'IN_PROGRESS' ){
					$("#chapterMenu").children().eq(i).find('.unlock_icon').hide();
					$("#chapterMenu").children().eq(i).find('.lock_icon').hide();
					$("#chapterMenu").children().eq(i).find('.progress_icon').show();
				}else if( currentRef.menuStatusArr[i].status == 'COMPLETED' ){
					$("#chapterMenu").children().eq(i).find('.unlock_icon').hide();
					$("#chapterMenu").children().eq(i).find('.lock_icon').hide();
					$("#chapterMenu").children().eq(i).find('.progress_icon').hide();
					$("#chapterMenu").children().eq(i).find('.completed_icon').show();
				}
			}
		}
		
		$("#chapterMenu li").each(function(ind){
			$(this).attr('data-status',currentRef.menuStatusArr[ind].status);
		});
		
		$("#chapterMenu li").each(function(ind){
			var curEleStatus = $(this).attr('data-status');
			var nextEleStatus = $(this).next().attr('data-status');
			if( ( curEleStatus == 'COMPLETED' ) && (nextEleStatus == 'NOT_STARTED') ){
				$(this).next().find('.icon_menu').hide();	
				$(this).next().find('.unlock_icon').show();	
			}
		});
	}
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}