var slide0Controller = function(){
	var intervalID;
	var _this = this;

	var degree = 1800;	
	var clicks = 0;
	var timer, timer2;
	
	this.init = function(data){
		console.log("--------- SLIDE0 CONTROLLER CALLED ----------------");	
	
		_this.data = data;		
		//intervalID = setInterval(_this.onAudioTimeUpdate,1);

		$('.topic_poc').css('opacity', 0);

		$('#spinButton').click(function() {
			
			var curAudioRef =  new AudioManager();
			curAudioRef.loadAudio("assets/media/audio/blank");
			
			clicks++;
			
			var newDegree = degree*clicks;
			var extraDegree = Math.floor(1 * (360 - 1 + 1)) + 180;
			totalDegree = newDegree+extraDegree;
		
			$('#spinWheel').css({
				'transform' : 'rotate(' + totalDegree + 'deg)'			
			});

			clearTimeout(timer);

			timer = setTimeout(function() {
				$('#spinButton').off( "click");
				$('.topic_poc').fadeTo('slow', 1);
				timer2 = setTimeout(function() {
					$("#parentContainer").html('');
					$('header,footer').fadeIn(1000);
					$("#requirementContainer").hide();
					$('title').html(_model.getCourseDataObj().projectTitle);
					new ApplicationController().init();
					
					/* appControllerObj.audioManager.stopAudio();
					appControllerObj.popupAudioManager.stopAudio();
		
					appControllerObj.popupAudioManager.loadAudio("assets/media/audio/blank");
					appControllerObj.audioManager.loadAudio("assets/media/audio/blank"); */
					
				}, 2500);
			}, 6000);
		});		
	}

	this.onAudioTimeUpdate = function(){
		
	}
	
	this.clear = function(){
		clearInterval(intervalID);
		clearTimeout(timer);
		clearTimeout(timer2);
	}
}