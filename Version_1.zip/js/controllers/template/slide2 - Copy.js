var slide2Controller = function(appRef){
	var intervalID, popIntervalID;
	var _this = this;
	var ccTextArr = [];
	var selectedId = 0;
	var popArrTime = [14000, 25000, 19000];
	var baseURL;

	var timer2;

	//_this.audioManager = new AudioManager();
	//_this.PopupAudioManager = new PopupAudioManager();
	
	this.init = function(data){
		console.log("--------- SLIDE2 CONTROLLER CALLED ----------------");		
		console.log(data);
		
		_this.data = data;
		baseURL = _model.getCourseDataObj().baseURL;
		
		ccTextArr = _this.data.ccText;
		
		intervalID = setInterval(_this.onAudioTimeUpdate,100);

		$(".hit_area div").css({'cursor': 'pointer', 'opacity': 0.1});

		$(".hit_area div").off("click").on("click", showAsscessories);
		$('.close').on("click", function() { $('.page2_popup').hide() });
		$('#disp_1,#disp_2,#disp_3,.page2_popup').hide();
		

	}		
	
	this.onAudioTimeUpdate = function(){
		console.log("Main Audio Time: "+ _model.getCurrentTime() );	
		
		console.log("Popup Audio Time"+ _model.getPopupCurrentTime() );	
		
		for(var i=0;i<ccTextArr.length;i++){
			if( ( ccTextArr[i].time < _model.getCurrentTime() ) && (ccTextArr[i].ended == 'false')  ){
				ccTextArr[i].ended = true;
				$(".cc_text p").html(ccTextArr[i].text);
				//console.log(ccTextArr[i].text);
			}
		}
		
		console.log( _model.getAudioStatus() );
	}
	
	this.clear = function(){
		clearInterval(intervalID);
		clearInterval(popIntervalID);
		//_this.PopupAudioManager.pauseAudio();
	}

	function showAsscessories() {
		selectedId = parseInt($(this).attr('id').substr(-1));
		$('#disp_1,#disp_2,#disp_3, #basediv, .hit_area').hide();		
		//_this.audioManager.pauseAudio();
		switch (selectedId) {
			case 1:
				//_this.PopupAudioManager.loadAudio(baseURL+"assets/media/audio/Slide_2A");
				appRef.playPauseFlag = false;
				appRef.isMainAudioPlaying = false;
				appRef.audioManager.stopAudio();
				
				appRef.popupAudioplayPauseFlag = true;
				appRef.isPopupAudioPlaying = true;
				appRef.popupAudioManager.loadAudio(baseURL+"assets/media/audio/Slide_2A",_this.onPopupAudioEnd);
				$("#playPauseBtn").attr('src', 'assets/images/player_control_pause_normal.png');
				break;
			case 2:
				//_this.PopupAudioManager.loadAudio(baseURL+"assets/media/audio/Slide_2B");
				appRef.playPauseFlag = false;
				appRef.isMainAudioPlaying = false;
				appRef.audioManager.stopAudio();
				
				appRef.popupAudioplayPauseFlag = true;
				appRef.isPopupAudioPlaying = true;
				appRef.popupAudioManager.loadAudio(baseURL+"assets/media/audio/Slide_2B",_this.onPopupAudioEnd);
				$("#playPauseBtn").attr('src', 'assets/images/player_control_pause_normal.png');
				break;
			case 3:
				//_this.PopupAudioManager.loadAudio(baseURL+"assets/media/audio/Slide_2C");
				appRef.playPauseFlag = false;
				appRef.isMainAudioPlaying = false;
				appRef.audioManager.stopAudio();
				
				appRef.popupAudioplayPauseFlag = true;
				appRef.isPopupAudioPlaying = true;
				appRef.popupAudioManager.loadAudio(baseURL+"assets/media/audio/Slide_2C",_this.onPopupAudioEnd);
				$("#playPauseBtn").attr('src', 'assets/images/player_control_pause_normal.png');
				break;
			default:
				break;
		}
		$('#disp_'+selectedId).fadeIn(500);

		//popIntervalID = setInterval(popupOnAudioTimeUpdate,100);
		//popupOnAudioTimeUpdate();
	}
	
	_this.onPopupAudioEnd = function(){
		//alert('onPopupAudioEnd');	
	}

	function popupOnAudioTimeUpdate () {
		clearInterval(intervalID);

		setTimeout(function() {			
			clearInterval(popIntervalID);
			if (selectedId == 1) {
				console.log('succed')
				clearInterval(popIntervalID);
				$('.page2_popup').show();
			} else {
				console.log('failed')
				$('#disp_1,#disp_2,#disp_3').hide();
				$('#disp_1').fadeIn(800);
				//_this.PopupAudioManager.loadAudio(baseURL+"assets/media/audio/Slide_2A");
				selectedId = 1;

				setTimeout(function() {	
					$('.page2_popup').show();
					console.log('succed2')
				}, popArrTime[selectedId-1]);
			}
		}, popArrTime[selectedId-1]);

		/*if (_this.PopupAudioManager.getCurrentTime() >= popArrTime[selectedId-1]) {
			if (selectedId == 1) {
				clearInterval(popIntervalID);
				//showpopup  $('#disp_'+selectedId).show();
			} else {
				$('#disp_1,#disp_2,#disp_3').hide();
				$('#disp_1').fadeIn(800);
				_this.PopupAudioManager.loadAudio(baseURL+"assets/media/audio/Slide_2A");
				selectedId = 1;
			}
		}	*/	
	}
}