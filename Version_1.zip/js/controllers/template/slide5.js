var slide5Controller = function(appRef){
	var intervalID;
	var _this = this;
	var ccTextArr = [];
	var audioPausePoints = [];
	
	this.init = function(data){
		console.log("--------- SLIDE5 CONTROLLER CALLED ----------------");	
		console.log(data);
		
		_this.data = data;
		
		console.log(_this.data.ccText)
		
		ccTextArr = _this.data.ccText;
		audioPausePoints = _this.data.audioPausePoints;
		
		intervalID = setInterval(_this.onAudioTimeUpdate,1);
		
		_this.initMascotAnimation();
	}

	this.initMascotAnimation = function(){
		
		$(".top_head").remove();
		$(".screen5 .row .col-md-8").html('<canvas class="top_head" width="920" height="640" id="mascotCharacter"></canvas>');
		
		stage = new createjs.Stage( document.getElementById("mascotCharacter") );

		spriteSheet = new createjs.SpriteSheet({
				framerate: 24,
				"images": ["assets/images/page_5/Thank you speech_0.png","assets/images/page_5/Thank you speech_1.png","assets/images/page_5/Thank you speech_2.png","assets/images/page_5/Thank you speech_3.png","assets/images/page_5/Thank you speech_4.png","assets/images/page_5/Thank you speech_5.png","assets/images/page_5/Thank you speech_6.png","assets/images/page_5/Thank you speech_7.png"],
				"frames": {"regX": 0, "height": 629, "count": 46, "regY": 0, "width": 915},
				"animations": {
					start: [0,45,true],
					stop : [0,false]
				}
			});
		spriteSheet.on("complete", function(event) {
			console.log("Complete", event);
		});
		spriteSheet.on("error", function(event) {
			console.log("Error", event);
		});

		curInstAnimation = new createjs.Sprite(spriteSheet);
		curInstAnimation.x = 0;
		curInstAnimation.y = 0;
		curInstAnimation.gotoAndStop('start');
		
		appRef.createJSRef = curInstAnimation;
		appRef.isCreateJSPlaying = true;
		
		stage.addChild(curInstAnimation);
		createjs.Ticker.timingMode = createjs.Ticker.RAF;
		createjs.Ticker.addEventListener("tick", stage);	
	}
	
	this.onAudioTimeUpdate = function(){
		console.log( _model.getCurrentTime() );	
		
		
		if(appRef.isMainAudioPlaying){
			var currentTime = _model.getCurrentTime();
		}else{
			var currentTime = _model.getPopupCurrentTime();
		}
		
		for(var i=0;i<audioPausePoints.length;i++){
			
			//console.log( "Pause:  "+ _model.getCurrentTime()  );
			
			if((audioPausePoints[i].time < currentTime ) && (audioPausePoints[i].ended == 'false')){
				
				audioPausePoints[i].ended = true;
				if(audioPausePoints[i].action == "stop"){
					//console.log(  _model.getCurrentTime()  );
					curInstAnimation.gotoAndStop(1);
				}else if(audioPausePoints[i].action == "play"){
					//console.log(  _model.getCurrentTime()  );
					if(appRef.playPauseFlag || appRef.popupAudioplayPauseFlag){
						curInstAnimation.play();
					}
				}
				
			}
		}
		
		for(var i=0;i<ccTextArr.length;i++){
			if( ( ccTextArr[i].time < _model.getCurrentTime() ) && (ccTextArr[i].ended == 'false')  ){
				ccTextArr[i].ended = true;
				$(".cc_text p").html(ccTextArr[i].text);
				console.log(ccTextArr[i].text);
				if(ccTextArr[i].text == "&nbsp;"){
					appRef.ccTextCloseHandler();
					curInstAnimation.gotoAndStop('stop');
					appRef.isCreateJSPlaying = false;					
				}
			}
		}
	}
	
	
	this.clear = function(){
		clearInterval(intervalID);
	}	
}