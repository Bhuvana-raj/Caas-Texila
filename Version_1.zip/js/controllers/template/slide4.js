var slide4Controller = function(appRef){
	var intervalID;
	var _this = this;
	var ccTextArr = [];
	var quePointArr = [];
	var allClicked = [0,0,0,0,0];
	var isEntered = false;
	
	this.init = function(data){
		console.log("--------- SLIDE4 CONTROLLER CALLED ----------------");
		
		_this.data = data;
		
		ccTextArr = _this.data.ccText;
		quePointArr = _this.data.quePoints;
				
		intervalID = setInterval(_this.onAudioTimeUpdate,1);
		
		$(".firstPart").show();
		$(".secondPart,.page4_models,.page4_bottompart").hide();
		
		$(".models_content").hide();
		$(".page4_models div").hide();
		$(".topic_part p").hide();

		$('.page4_popup .page_4close').on('click', function() {
			$(".page4_popup, #mobileMenuOverlay").hide();
			appRef.popupAudioManager.stopAudio();
			appRef.ccTextCloseHandler();
			
		})
	
		//_this.onAccessoryClick();
	}	


	this.onAccessoryClick = function(){
		
		var curIndex = parseInt($(this).index());
		allClicked[curIndex] = 1;
		
		ccTextArr = _this.data.clickableContent[curIndex].ccTextSlide;
		
		for(var i=0;i<ccTextArr.length;i++){
			ccTextArr[i].ended = 'false';		
		}
		
		$(".page4_models div").removeClass('active');
		$(this).addClass('active');

		appRef.ccTextShowHandler();

		/*var isMobile = {
			Android: function() {
				return navigator.userAgent.match(/Android/i);
			},
			BlackBerry: function() {
				return navigator.userAgent.match(/BlackBerry/i);
			},
			iOS: function() {
				return navigator.userAgent.match(/iPhone|iPad|iPod/i);
			},
			Opera: function() {
				return navigator.userAgent.match(/Opera Mini/i);
			},
			Windows: function() {
				return navigator.userAgent.match(/IEMobile/i);
			},
			any: function() {
				return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
			}
		};

		var isAndroid = /android/i.test(navigator.userAgent.toLowerCase());
		var isiPad = /ipad/i.test(navigator.userAgent.toLowerCase());
		var isiPod = /ipod/i.test(navigator.userAgent.toLowerCase());
		var isiDevice = /ipad|iphone|ipod/i.test(navigator.userAgent.toLowerCase());

		if (isMobile.any() && (isiDevice || isAndroid)) {		
		//if (/Android|webOS|iPhone|BB|PlayBook|IEMobile|Windows Phone|Kindle|Silk|Opera Mini/i.test(navigator.userAgent)) {
			$('.page4_popup .popup_content').html('').html(_this.data.clickableContent[curIndex].popupContent);
			$('.page4_popup .popup_title').html(_this.data.clickableContent[curIndex].popupTitle);
			$(".page4_popup").show();
		} else {
			$(".models_content").html(_this.data.clickableContent[curIndex].popupContent);
			$(".models_content,.page4_bottompart").show();
		}*/

		if(/Mobile/i.test(navigator.userAgent) && !/ipad/i.test(navigator.userAgent) ){
			$('.page4_popup .popup_content').html('').html(_this.data.clickableContent[curIndex].popupContent);
			$('.page4_popup .popup_title').html(_this.data.clickableContent[curIndex].popupTitle);
			$(".page4_popup").show();
			$("#mobileMenuOverlay").show();
		} else {
			$(".models_content").html(_this.data.clickableContent[curIndex].popupContent);
			$(".models_content,.page4_bottompart").show();
		}
				
		appRef.playPauseFlag = false;
		appRef.isMainAudioPlaying = false;
		appRef.audioManager.stopAudio();
				
		appRef.popupAudioplayPauseFlag = true;
		appRef.isPopupAudioPlaying = true;
		appRef.popupAudioManager.loadAudio(_model.getCourseDataObj().baseURL+"assets/media/audio/"+_this.data.clickableContent[curIndex].popupAudio,_this.onPopupAudioEnd);
		$("#playPauseBtn img").attr('src', 'assets/images/player_control_pause_normal.png');

		
	}
	
	this.onPopupAudioEnd = function(){
		var count = 0;
		for(var i = 0; i<5; i++) {			
			if (allClicked[i] == 1) {
				count++;
			} else {
				break;
			}
		}
		if (count == 5) {
			_model.setTemplateStatus(true);
			EventManager.getInstance().dispatchCustomEvent(window, StaticLibrary.AUDIO_ENDED_EVENT, true, null);
		}
		$("#playPauseBtn img").attr('src', 'assets/images/player_control_play_normal.png');
	}
	
	this.onAudioTimeUpdate = function(){
		//console.log( _model.getCurrentTime() );	
		
		if(appRef.isMainAudioPlaying){
			var currentTime = _model.getCurrentTime();
		}else{
			var currentTime = _model.getPopupCurrentTime();
		}
		
		for(var i=0;i<quePointArr.length;i++){
			if( ( quePointArr[i].time < _model.getCurrentTime() ) && (quePointArr[i].ended == 'false')  ){
				quePointArr[i].ended = true;
				$(".firstPart").fadeOut(600,function(){
					$(".page4_models,.secondPart").fadeIn(600);
				});
				
				$("."+quePointArr[i].className).fadeIn(600);
			}
		}	
		
		for(var i=0;i<ccTextArr.length;i++){
			if( ( ccTextArr[i].time < currentTime ) && (ccTextArr[i].ended == 'false')  ){
				ccTextArr[i].ended = true;
				$(".cc_text p").html(ccTextArr[i].text);
				
				if(ccTextArr[i].text == "&nbsp;"){					
					appRef.ccTextCloseHandler();
				}
			}
		}
		
		if (  _model.getAudioStatus() && !isEntered  ) {
			isEntered = true;
			$(".page4_models div").on('click',_this.onAccessoryClick).css('cursor','pointer');
		}
		
	}
	
	this.clear = function(){
		clearInterval(intervalID);
	}
}