var slide5Controller = function(currentRef){
	var intervalID;
	var _this = this;
	var ccTextArr = [];
	
	this.init = function(data){
		console.log("--------- SLIDE5 CONTROLLER CALLED ----------------");	
		console.log(data);
		
		_this.data = data;
		
		console.log(_this.data.ccText)
		
		ccTextArr = _this.data.ccText;
		
		intervalID = setInterval(_this.onAudioTimeUpdate,1);
	}	
	
	this.onAudioTimeUpdate = function(){
		console.log( _model.getCurrentTime() );	
		for(var i=0;i<ccTextArr.length;i++){
			if( ( ccTextArr[i].time < _model.getCurrentTime() ) && (ccTextArr[i].ended == 'false')  ){
				ccTextArr[i].ended = true;
				console.log(ccTextArr[i].text);
			}
		}
	}
	
	
	this.clear = function(){
		clearInterval(intervalID);
	}	
}