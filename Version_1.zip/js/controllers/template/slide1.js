var slide1Controller = function(appRef){
	var intervalID;
	var _this = this;
	var syncTimer = [4.5, 9.0];
	var imageTimer = 21;
	var count = 0;	
	var ccTextArr = [];
	var isEntered = false;
	var stage;
	var currentFps = 20;
	var animationSettings = {
		fps: currentFps,
		loop: true,
		autoplay: false,
		animations: {
			walkRight: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 13, 14]
		},
		complete: function(){
			// this will be called when
			// there is no loop and the
			// animation finishes
			console.log('animation End');
			$('.animation').animateSprite('restart');
		}
	};
	var audioPausePoints = [];
	
	this.init = function(data){
		console.log("--------- SLIDE1 CONTROLLER CALLED ----------------");		
		console.log(data);

		_this.data = data;

		$(".page_screen p").css('opacity', '0');
		
		ccTextArr = _this.data.ccText;
		intervalID = setInterval(_this.onAudioTimeUpdate,1);
		
		//window.requestInterval(_this.onAudioTimeUpdate, 60);

		$('.animation').animateSprite(animationSettings);
		$('.model_bg').hide();
		$(".first_img").fadeIn(600);
		
		var play = function(){
			$('.animation').animateSprite('play');
		}
		play();
		
		_this.initMascotAnimation();
	}		
	
	
	this.initMascotAnimation = function(){
		$(".slide_1_img_part_right").html('<canvas width="350" height="640" id="mascotCharacter"></canvas>');
		
		stage = new createjs.Stage( document.getElementById("mascotCharacter") );

		spriteSheet = new createjs.SpriteSheet({
				framerate: 24,
				"images": ["assets/images/page_1/Mascot character Sprite_0.png","assets/images/page_1/Mascot character Sprite_1.png","assets/images/page_1/Mascot character Sprite_2.png"],
				"frames": {"regX": 0, "height": 628, "count": 39, "regY": 0, "width": 345},
				"animations": {
					start: [0,38,true],
					stop : [0,false]
				}
			});
		spriteSheet.on("complete", function(event) {
			console.log("Complete", event);
		});
		spriteSheet.on("error", function(event) {
			console.log("Error", event);
		});

		curInstAnimation = new createjs.Sprite(spriteSheet);
		curInstAnimation.x = 0;
		curInstAnimation.y = 0;
		curInstAnimation.gotoAndStop('start');
		
		appRef.createJSRef = curInstAnimation;
		appRef.isCreateJSPlaying = true;
		
		stage.addChild(curInstAnimation);
		createjs.Ticker.timingMode = createjs.Ticker.RAF;
		createjs.Ticker.addEventListener("tick", stage);	
	}
		
	this.onAudioTimeUpdate = function(){
		if (_model.getCurrentTime() > syncTimer[count])	{	
			//$(".page_screen p:eq("+count+")").css('visibility', 'visible');
			$(".page_screen p:eq("+count+")").animate({opacity:1},600);		
			//$('.page_screen p:eq('+count+')').fadeIn(800);			
			count++;
			/*if (count == 2){
				$(".first_img").fadeOut(300,function(){
					$(".second_img").fadeIn(300);
				});
			}*/
			//$('.model_bg').attr('src', 'assets/images/page_1/page_01_img_01.png');
		}
		
		//console.log( _model.getCurrentTime() );

		if (_model.getCurrentTime() > imageTimer) {
			$(".first_img").fadeOut(300,function(){
				$(".second_img").fadeIn(300);
			});
		}
	
		if (count >= syncTimer.length) {
			//clearInterval(intervalID);
		}
	
		for(var i=0;i<ccTextArr.length;i++){
			if((ccTextArr[i].time < _model.getCurrentTime() ) && (ccTextArr[i].ended == 'false')){
				ccTextArr[i].ended = true;
				$(".cc_text p").html(ccTextArr[i].text);
				if(ccTextArr[i].text == "&nbsp;"){
					appRef.ccTextCloseHandler();
					curInstAnimation.gotoAndStop('stop');
					appRef.isCreateJSPlaying = false;
				}
			}
		}
		
		var audioPausePoints = _this.data.audioPausePoints;
		
		
		for(var i=0;i<audioPausePoints.length;i++){
			
			console.log( "Pause:  "+ _model.getCurrentTime()  );
			
			if((audioPausePoints[i].time < _model.getCurrentTime() ) && (audioPausePoints[i].ended == 'false')){
				
				audioPausePoints[i].ended = true;
				if(audioPausePoints[i].action == "stop"){
					//console.log(  _model.getCurrentTime()  );
					curInstAnimation.gotoAndStop(1);
				}else if(audioPausePoints[i].action == "play"){
					//console.log(  _model.getCurrentTime()  );
					if(appRef.playPauseFlag || appRef.popupAudioplayPauseFlag){
						curInstAnimation.play();
					}
				}
				
			}
		}
		
		
		if (  _model.getAudioStatus() && !isEntered  ) {
			isEntered = true;
			curInstAnimation.gotoAndStop('stop');
			_model.setTemplateStatus(true);
			EventManager.getInstance().dispatchCustomEvent(window, StaticLibrary.AUDIO_ENDED_EVENT, true, null);
		}
	}
	
	
	this.clear = function(){
		$('.animation').animateSprite('stop');
		clearInterval(intervalID);
		createjs.Ticker.removeEventListener("tick", stage);	
	}
}