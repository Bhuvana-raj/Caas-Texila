var slide2Controller = function(appRef){
	var intervalID;
	var _this = this;
	var ccTextArr = [];
	var selectedId = 0;
	var selectIncorrect = false;
	var baseURL;
	var isEntered = false;
	var stage;
	var audioPausePoints = [];
	//_this.audioManager = new AudioManager();
	//_this.PopupAudioManager = new PopupAudioManager();
	
	this.init = function(data){
		console.log("--------- SLIDE2 CONTROLLER CALLED ----------------");		
	
		_this.data = data;
		baseURL = _model.getCourseDataObj().baseURL;
		
		ccTextArr = _this.data.ccText;
		
		audioPausePoints = _this.data.audioPausePoints;
		
		intervalID = setInterval(_this.onAudioTimeUpdate,1);
		
		$('.page_2close').on("click", function() { 
			appRef.popupAudioManager.stopAudio();
			$('.page2_popup, .popUpoverlay').hide();
			_model.setAudioStatus(true);
			_model.setTemplateStatus(true);
			EventManager.getInstance().dispatchCustomEvent(window, StaticLibrary.AUDIO_ENDED_EVENT, true, null);
		});
		$('#disp_1,#disp_2,#disp_3,.page2_popup, .popUpoverlay, .popup_title_x').hide();
		$(".hit_area div").off("click").on("click", showAsscessories);

		_this.initMascotAnimation();
	}

	this.initMascotAnimation = function(){
		
		$(".top_head").remove();
		$("#basediv").append('<canvas class="top_head" width="220" height="220" id="mascotCharacter"></canvas>');
		
		stage = new createjs.Stage( document.getElementById("mascotCharacter") );

		spriteSheet = new createjs.SpriteSheet({
				framerate: 24,
				"images": ["assets/images/page_2/Inner page mascot speech_01.png"],
				"frames": {"regX": 0, "height": 214, "count": 39, "regY": 0, "width": 214},
				"animations": {
					start: [0,10,true],
					stop : [0,false]
				}
			});
		spriteSheet.on("complete", function(event) {
			console.log("Complete", event);
		});
		spriteSheet.on("error", function(event) {
			console.log("Error", event);
		});

		curInstAnimation = new createjs.Sprite(spriteSheet);
		curInstAnimation.x = 0;
		curInstAnimation.y = 0;
		curInstAnimation.gotoAndStop('start');
		
		appRef.createJSRef = curInstAnimation;
		appRef.isCreateJSPlaying = true;
		
		stage.addChild(curInstAnimation);
		createjs.Ticker.timingMode = createjs.Ticker.RAF;
		createjs.Ticker.addEventListener("tick", stage);	
	}
	
	this.onAudioTimeUpdate = function(){
		
		if(appRef.isMainAudioPlaying){
			var currentTime = _model.getCurrentTime();
		}else{
			var currentTime = _model.getPopupCurrentTime();
		}
				
		for(var i=0;i<audioPausePoints.length;i++){
			
			//console.log( "Pause:  "+ _model.getCurrentTime()  );
			
			if((audioPausePoints[i].time < currentTime ) && (audioPausePoints[i].ended == 'false')){
				
				audioPausePoints[i].ended = true;
				if(audioPausePoints[i].action == "stop"){
					//console.log(  _model.getCurrentTime()  );
					curInstAnimation.gotoAndStop(1);
				}else if(audioPausePoints[i].action == "play"){
					//console.log(  _model.getCurrentTime()  );
					if(appRef.playPauseFlag || appRef.popupAudioplayPauseFlag){
						curInstAnimation.play();
					}
				}
				
			}
		}
		
		for(var i=0;i<ccTextArr.length;i++){
			if( ( ccTextArr[i].time < currentTime ) && (ccTextArr[i].ended == 'false')){
				ccTextArr[i].ended = true;
				$(".cc_text p").html(ccTextArr[i].text);
				//console.log(ccTextArr[i].text);
				if(ccTextArr[i].text == "&nbsp;"){
					appRef.ccTextCloseHandler();
					curInstAnimation.gotoAndStop('stop');
					appRef.isCreateJSPlaying = false;
				}
			}
		}

		if (  _model.getAudioStatus() && !isEntered  ) {
			isEntered = true;
			//$(".hit_area div").css({'cursor': 'pointer', 'opacity':9});
			$(".hit_area div").off("click").on("click", showAsscessories);
		}
	}
	
	this.clear = function(){
		clearInterval(intervalID);
		createjs.Ticker.removeEventListener("tick", stage);	
	}

	function showAsscessories() {
		selectedId = parseInt($(this).attr('id').substr(-1));
		$('#disp_1,#disp_2,#disp_3, #basediv, .hit_area').hide();		
		showAssets();
	}

	function showAssets() {		
		switch (selectedId) {
			case 1:
				appRef.playPauseFlag = false;
				appRef.isMainAudioPlaying = false;
				appRef.audioManager.stopAudio();
				
				appRef.popupAudioplayPauseFlag = true;
				appRef.isPopupAudioPlaying = true;
				if (selectIncorrect) {
					appRef.popupAudioManager.loadAudio(baseURL+"assets/media/audio/Slide_2A_1",_this.onPopupAudioEnd);
					ccTextArr = _this.data.ccTextSlide2A1;
					audioPausePoints = _this.data.audioPausePoints2A1;
				} else {
					appRef.popupAudioManager.loadAudio(baseURL+"assets/media/audio/Slide_2A",_this.onPopupAudioEnd);
					ccTextArr = _this.data.ccTextSlide2A;
					audioPausePoints = _this.data.audioPausePoints2A;
				}
				$("#playPauseBtn img").attr('src', 'assets/images/player_control_pause_normal.png');
				curInstAnimation.gotoAndPlay('start');
				break;
			case 2:
				appRef.playPauseFlag = false;
				appRef.isMainAudioPlaying = false;
				appRef.audioManager.stopAudio();
				
				appRef.popupAudioplayPauseFlag = true;
				appRef.isPopupAudioPlaying = true;
				appRef.popupAudioManager.loadAudio(baseURL+"assets/media/audio/Slide_2B",_this.onPopupAudioEnd);
				$("#playPauseBtn img").attr('src', 'assets/images/player_control_pause_normal.png');				
				ccTextArr = _this.data.ccTextSlide2B;	
				audioPausePoints = _this.data.audioPausePoints2B;
				curInstAnimation.gotoAndPlay('start');
				break;
			case 3:
				appRef.playPauseFlag = false;
				appRef.isMainAudioPlaying = false;
				appRef.audioManager.stopAudio();
				
				appRef.popupAudioplayPauseFlag = true;
				appRef.isPopupAudioPlaying = true;
				appRef.popupAudioManager.loadAudio(baseURL+"assets/media/audio/Slide_2C",_this.onPopupAudioEnd);
				$("#playPauseBtn img").attr('src', 'assets/images/player_control_pause_normal.png');				
				ccTextArr = _this.data.ccTextSlide2C;
				audioPausePoints = _this.data.audioPausePoints2C;
				curInstAnimation.gotoAndPlay('start');
				break;
			default:
				break;
		}
		$('.top_head').appendTo( $('#disp_'+selectedId) );
		$('#disp_'+selectedId).fadeIn(500);
		appRef.ccTextShowHandler();
	}
	
	_this.onPopupAudioEnd = function() {
		$('#disp_1,#disp_2,#disp_3, #basediv, .hit_area').hide();
		curInstAnimation.gotoAndStop('stop');
		//$('#disp_'+selectedId).show();	
		//appRef.popupAudioManager.loadAudio(baseURL+"assets/media/audio/Slide_popup_2A_B_C",_this.onPageComplete);
		//$('.page2_popup, .popUpoverlay').show();
		 if (selectedId == 1) {	
			$('#disp_'+selectedId).show();		
			appRef.popupAudioManager.loadAudio(baseURL+"assets/media/audio/Slide_popup_2A_B_C",_this.onPageComplete);
			$('.page2_popup, .popUpoverlay').show();
		} else {	
			selectedId = 1;
			selectIncorrect = true;
			showAssets();
		}
	}

	_this.onPageComplete = function() { 
		$('.popup_title_x').show();		
 	}
} 