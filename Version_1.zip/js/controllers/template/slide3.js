var slide3Controller = function(appRef){
	var intervalID;
	var _this = this;
	var ccTextArr = [];
	var getDragID;
	var timer;
	var baseURL;
	var fbTime = [3.5, 8.0, 10.0];
	var dropPos = [['7.5%', '43.5%'],['7.5%', '61.5%'],['7.5%', '47.5%']];
	var dropPos2 = [['7.5%', '43.5%'],['7.5%', '65.5%'],['3.5%', '57.5%']];
	var isEntered = false;
	var audioPausePoints = [];
	
	this.init = function(data){
		console.log("--------- SLIDE3 CONTROLLER CALLED ----------------");	
		
		_this.data = data;
		baseURL = _model.getCourseDataObj().baseURL;
		
		ccTextArr = _this.data.ccText;
				
		audioPausePoints = _this.data.audioPausePoints;
		
		$('#disp_1, .arrow_pointer, .imageplace_drop img').hide();
		
		intervalID = setInterval(_this.onAudioTimeUpdate,100);
		
		$(".drag").draggable({
			containment: '#parentContainer',
			start: function(event, ui) {
				getDragID = parseInt($(this).attr('id').split('_')[1]);
				$('.imageplace_drop').addClass('blink');				
			},
			drag: function(event, ui) {
				$(this).css('zIndex','101');
			},
			revert: function(x) 
			{
				$('#drag_'+getDragID).css('zIndex','100');
				$('.imageplace_drop').removeClass('blink');
				if (!x) {
					return true;
				}
			}
		});

		$('.imageplace_drop').droppable({
			drop: function(event, ui) {
				$(".drag").css({'cursor':'default'});
				/*if(/Mobile/i.test(navigator.userAgent) && !/ipad/i.test(navigator.userAgent) ){
					$('#drag_'+getDragID).css({'bottom':dropPos[getDragID-1][0], 'left':dropPos[getDragID-1][1]});
				} else {
					$('#drag_'+getDragID).css({'bottom':dropPos2[getDragID-1][0], 'left':dropPos2[getDragID-1][1]});
				}*/

				$('.imageplace_drop #img_'+getDragID).show();

				$(this).droppable("destroy");
				$('#drag_'+getDragID).css({'zIndex':'100','visibility':'hidden' });
				$('.drag').draggable('disable');

				appRef.ccTextShowHandler();

				appRef.playPauseFlag = false;
				appRef.isMainAudioPlaying = false;
				appRef.audioManager.stopAudio();
				
				appRef.popupAudioplayPauseFlag = true;
				appRef.isPopupAudioPlaying = true;				
				
				if (getDragID == 1) {
					$('#disp_1').fadeIn(800);
					$('.top_head').appendTo( $('#disp_1') );
					$('#basediv').hide();
					appRef.popupAudioManager.loadAudio(baseURL+"assets/media/audio/Slide_3A",_this.onPopupAudioEnd);
					ccTextArr = _this.data.ccTextSlide3A;
					audioPausePoints = _this.data.audioPausePoints3A;
					curInstAnimation.gotoAndStop('start');
					$("#playPauseBtn img").attr('src', 'assets/images/player_control_pause_normal.png');
				} else {
					timer = setTimeout(function(){ $('#disp_1, .popup_page2 ul li:eq(1)').fadeIn(800); $('.top_head').appendTo( $('#disp_1') ); $('#basediv').hide() }, 6000);
					appRef.popupAudioManager.loadAudio(baseURL+"assets/media/audio/Slide_3B",_this.onPopupAudioEnd);
					ccTextArr = _this.data.ccTextSlide3B;
					audioPausePoints = _this.data.audioPausePoints3B;
					curInstAnimation.gotoAndStop('start');
					$("#playPauseBtn img").attr('src', 'assets/images/player_control_pause_normal.png');
				}
			}
		});
		//$('.drag').draggable('disable');	
		$(".drag").css({'z-index': 100, 'cursor':'pointer'});	
		
		_this.initMascotAnimation();
	}

	this.initMascotAnimation = function(){
		
		$(".top_head").remove();
		$("#basediv").append('<canvas class="top_head" width="220" height="220" id="mascotCharacter"></canvas>');
		
		stage = new createjs.Stage( document.getElementById("mascotCharacter") );

		spriteSheet = new createjs.SpriteSheet({
				framerate: 24,
				"images": ["assets/images/page_2/Inner page mascot speech_01.png"],
				"frames": {"regX": 0, "height": 214, "count": 39, "regY": 0, "width": 214},
				"animations": {
					start: [0,10,true],
					stop : [0,false]
				}
			});
		spriteSheet.on("complete", function(event) {
			console.log("Complete", event);
		});
		spriteSheet.on("error", function(event) {
			console.log("Error", event);
		});

		curInstAnimation = new createjs.Sprite(spriteSheet);
		curInstAnimation.x = 0;
		curInstAnimation.y = 0;
		curInstAnimation.gotoAndStop('start');
		
		appRef.createJSRef = curInstAnimation;
		appRef.isCreateJSPlaying = true;
		
		stage.addChild(curInstAnimation);
		createjs.Ticker.timingMode = createjs.Ticker.RAF;
		createjs.Ticker.addEventListener("tick", stage);	
	}
	
	this.onAudioTimeUpdate = function() {

		if (_model.getPopupCurrentTime() > fbTime[getDragID-1]) $('.arrow_pointer').fadeIn(800);
		
		if(appRef.isMainAudioPlaying){
			var currentTime = _model.getCurrentTime();
		}else{
			var currentTime = _model.getPopupCurrentTime();
		}
		
		
		for(var i=0;i<audioPausePoints.length;i++){
			
			//console.log( "Pause:  "+ _model.getCurrentTime()  );
			
			if((audioPausePoints[i].time < currentTime ) && (audioPausePoints[i].ended == 'false')){
				
				audioPausePoints[i].ended = true;
				if(audioPausePoints[i].action == "stop"){
					//console.log(  _model.getCurrentTime()  );
					curInstAnimation.gotoAndStop(1);
				}else if(audioPausePoints[i].action == "play"){
					//console.log(  _model.getCurrentTime()  );
					if(appRef.playPauseFlag || appRef.popupAudioplayPauseFlag){
						curInstAnimation.play();
					}
				}
				
			}
		}
		
		for(var i=0;i<ccTextArr.length;i++){
			if( ( ccTextArr[i].time < currentTime ) && (ccTextArr[i].ended == 'false')  ){
				ccTextArr[i].ended = true;
				$(".cc_text p").html(ccTextArr[i].text);
				
				if(ccTextArr[i].text == "&nbsp;"){
					appRef.ccTextCloseHandler();
					curInstAnimation.gotoAndStop('stop');
					appRef.isCreateJSPlaying = false;
				}
			}
		}

		if (_model.getAudioStatus() && !isEntered) {
			$('.drag').draggable('enable');
			$(".drag").css({'z-index': 100, 'cursor':'pointer'});
			isEntered = true;
		}
	}
	
	this.clear = function(){
		createjs.Ticker.removeEventListener("tick", stage);	
		clearInterval(intervalID);
		if (timer) clearTimeout(timer);
	}

	_this.onPopupAudioEnd = function() {
		_model.setAudioStatus(true);
		_model.setTemplateStatus(true);
		EventManager.getInstance().dispatchCustomEvent(window, StaticLibrary.AUDIO_ENDED_EVENT, true, null);
	}
}