
var _model = DataManager.getInstance();

$(document).ready(function(){

	$('[data-toggle="tooltip"]').tooltip();
	
    StaticLibrary.HIDE_PRE_LOADER();

	trace(":: Framework Loading Started ::");

    //setup the jPlayer plugin and only on the ready of the plugin the Framework will start the calls.
    $("#jquery_jplayer_1").jPlayer({
        ready: function () {
            $(this).jPlayer("setMedia", {
                mp3: "assets/media/audio/blank.mp3",
                ogg: "assets/media/audio/blank.ogg"
            });

            _model.setAudioReference($(this));

            trace(":: Audio Loading for first Time completed ::");
            trace(":: Loading of Application Configuration Started ::");
            var apiServiceLoadAppData = new APIService();
            apiServiceLoadAppData.loadAppConfigData(StaticLibrary.APP_DATA_URL, "true", StaticLibrary.DATA_TYPE, null, loadAppDataSuccessHandler);
        },
        ended:function(){
            trace(":: Audio Loading Completed from the shell, event triggered ::");
			_model.setAudioStatus(true);
            EventManager.getInstance().dispatchCustomEvent(window, StaticLibrary.AUDIO_ENDED_EVENT, true, null);

        },
        timeupdate:function(event){

            //console.log("Audio Current Time : " + event.jPlayer.status.currentTime);
			
			_model.setCurrentTime(event.jPlayer.status.currentTime);
			
			console.log(event.jPlayer.status.currentPercentAbsolute);
			
            if((event.jPlayer.status.currentTime >= 0.10) && (_model.getPreloaderFlag())){
                StaticLibrary.HIDE_PRE_LOADER();
            }
			
			$(".slider_marker").width(event.jPlayer.status.currentPercentAbsolute+"%");
			
            //trace("Audio Current Time : " + event.jPlayer.status.currentTime);
            //trace("Audio Total Duration : " + event.jPlayer.status.duration);
        }
    });
	
	//Popup audio player
	$("#jquery_jplayer_2").jPlayer({
        ready: function () {
            $(this).jPlayer("setMedia", {
                mp3: "assets/media/audio/blank.mp3",
                ogg: "assets/media/audio/blank.ogg"
            });

            _model.setPopupAudioReference($(this));
        },
        ended:function(){
           
        },
        timeupdate:function(event){

            //console.log("Audio Current Time : " + event.jPlayer.status.currentTime);

            if((event.jPlayer.status.currentTime >= 0.10) && (_model.getPreloaderFlag())){
                StaticLibrary.HIDE_PRE_LOADER();
            }

            //trace("Audio Current Time : " + event.jPlayer.status.currentTime);
            //trace("Audio Total Duration : " + event.jPlayer.status.duration);
        }
    });
	
});
 
function loadAppDataSuccessHandler(data){
    trace(":: Loading of Application Configuration Completed ::");
    DataParser.parseAppData(data);
    trace(":: Data Parsing for Application Configuration Completed ::");

    trace(":: Loading of Course Configuration Started ::");

    var courseDataURL = "courses/" + _model.getAppDataObj().courseName + "/assets/data/courseData.json?version=" + StaticLibrary.generateRandom();
	if($('#menuBoxContainer').width() == 800){
		$(".menu_screen").css("height", "1059px")
 } 
	/* if(_model.getAppDataObj().courseName == "module2" || _model.getAppDataObj().courseName == "module3"){
	$("#menuBoxContainer > .container").css("overflow", "initial"); 	
	
	}
	if(_model.getAppDataObj().courseName == "module3"){
		$(".header_part_middle > h4").css("font-size", "15px");
	}	
	if(_model.getAppDataObj().courseName == "module5"){
		$(".header_part_middle > h4").css("font-size", "16px");
	} */
    var apiServiceLoadCourseData = new APIService();
    apiServiceLoadCourseData.loadCourseData(courseDataURL, "true", StaticLibrary.DATA_TYPE, null, loadCourseDataSuccessHandler);
}

function loadCourseDataSuccessHandler(data){

    trace(":: Loading of Course Configuration Completed ::");
    DataParser.parseCourseData(data);	
	trace(":: Data Parsing for Course Config Completed ::");

    trace("------------------------------------------");
    trace(_model.getAppDataObj());
    trace("------------------------------------------");
    trace(_model.getCourseDataObj());
	
	trace( _model.getAppDataObj().scorm );
	
	if(_model.getAppDataObj().scorm == "scorm"){
		var scormAPIObj = new scormAPI();
		_model.setScormReference(scormAPIObj);	
	}
	
    $("#projectHeading").html(_model.getCourseDataObj().projectTitle);
    $("#courseTitleTxt").html(_model.getCourseDataObj().title);
    $("#durationTxt, #moduleDuration").html("Duration: <b>" + _model.getCourseDataObj().duration + "</b>");
    $("#innerHeading").html(_model.getCourseDataObj().projectTitle);
    $("#innerText").html(_model.getCourseDataObj().title);
    $("#desktopHelpImage").attr("src", _model.getCourseDataObj().baseURL + "assets/images/" + _model.getCourseDataObj().desktopHelp);
	
	$('header,footer').hide();

    trace("Header Height : " + $("#header").height());
    trace("Footer Height : " + $("#footer").height());

    if(_model.getAppDataObj().scorm == "scorm"){
		var scormAPIObj = new scormAPI();
		_model.setScormReference(scormAPIObj);
		$("#requirementContainer").show();
		$("#innerContainer").hide();
		$("#landingPage").hide();
		checkAllRequirements();
		var courseTitle = _model.getCourseDataObj().title.split(':');
		$("#courseTitleText").html('L&T Formwork - '+courseTitle[1]);
		$("#courseLink").on('click',function(){
			$("#requirementContainer").hide();
			$("#innerContainer").show();
			$('title').html(_model.getCourseDataObj().projectTitle);
			var appControllerObj = new ApplicationController();
			appControllerObj.init();
		});
	}else{
		
		/* $("#parentContainer").load("",function(){
			// Call the Start Page here....			
		}); */
		
			$('header,footer').show();
			$("#requirementContainer").hide();
			$('title').html(_model.getCourseDataObj().projectTitle);
			var appControllerObj = new ApplicationController();
			appControllerObj.init();
	}
}



function quitSCORM(){
	var curObj = _model.getScormReference();
	curObj.exitScorm();
}
